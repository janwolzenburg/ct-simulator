var class_detector_properties =
[
    [ "DetectorProperties", "class_detector_properties.html#a57a3c3b31351ced87749f2aad8bbecef", null ],
    [ "arc_angle", "class_detector_properties.html#a22b44bc4387360eed6ae02e3b5ff97bf", null ],
    [ "detector_focus_distance", "class_detector_properties.html#acfb03a89e9dfd4deaf39b0d275313c23", null ],
    [ "has_anti_scattering_structure", "class_detector_properties.html#a7aab5912a9c2abc184aa59f49cddb72c", null ],
    [ "max_angle_allowed_by_structure", "class_detector_properties.html#ac40f063b0e8b6de3d43715ee1d9b5f17", null ],
    [ "number_of_pixel", "class_detector_properties.html#aaa4aa3972f1f96c4cb8bc00b20a9ecc4", null ],
    [ "row_width", "class_detector_properties.html#a1b1fd3be809683365db35747fcadc451", null ]
];