var class_x_ray_detector =
[
    [ "XRayDetector", "class_x_ray_detector.html#aa04cc9f87cff44ee5159804042b3b7c2", null ],
    [ "ConvertPixelArray", "class_x_ray_detector.html#af246cef22b19d2d6f51b903183658bfa", null ],
    [ "DetectRay", "class_x_ray_detector.html#aacc0b83b844b5ab44d1505a09804a952", null ],
    [ "pixel_array", "class_x_ray_detector.html#a287d531d33cc4a75b8e69a0f1024f566", null ],
    [ "properties", "class_x_ray_detector.html#a294b124302d5ba8bfb7514ec491303fe", null ],
    [ "ResetDetectedRayPorperties", "class_x_ray_detector.html#ad40219e100c4b992b1066e866e47c266", null ],
    [ "TryDetection", "class_x_ray_detector.html#a131d56ae798c266e6b6a5f5d44db6aaa", null ],
    [ "UpdateProperties", "class_x_ray_detector.html#a0b07967c1ae678ea9606fd9155b9dd8b", null ]
];