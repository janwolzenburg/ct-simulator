var class_natural_number_range =
[
    [ "NaturalNumberRange", "class_natural_number_range.html#ab1521ec985e0d27559c00735c7c1a6d3", null ],
    [ "end", "class_natural_number_range.html#ad342578646c97654625b8e62b7384258", null ],
    [ "end", "class_natural_number_range.html#ad01b0e1a67cd6ecddba422733532a824", null ],
    [ "start", "class_natural_number_range.html#a0a6f755f7ee8ee7bc52e50d5cc3e9234", null ],
    [ "start", "class_natural_number_range.html#af008d52815eb10f5f0e824cd6fc42484", null ]
];