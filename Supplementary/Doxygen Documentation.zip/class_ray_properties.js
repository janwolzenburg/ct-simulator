var class_ray_properties =
[
    [ "RayProperties", "class_ray_properties.html#aac9559c37c7bd60c5db08f0de650f9f4", null ],
    [ "RayProperties", "class_ray_properties.html#a74855aca07d93be64f9f2b0197af039b", null ],
    [ "AttenuateSpectrum", "class_ray_properties.html#a9cc781305a26aa308997c9b9be3a0745", null ],
    [ "definitely_hits_expected_pixel", "class_ray_properties.html#a6a60972812b44d90ab743295200d767e", null ],
    [ "energy_spectrum", "class_ray_properties.html#a8a4cac575c6b55e767fbae1d384eb4fa", null ],
    [ "expected_detector_pixel_index", "class_ray_properties.html#a260f2e779d1897c80f6e859938dd1ba0", null ],
    [ "ScaleSpectrumEvenly", "class_ray_properties.html#a8c91d41a4d15fe2a9e5d393561a1f78e", null ],
    [ "simple_intensity", "class_ray_properties.html#a53f454f2caa45cea64500afcf19a6e8f", null ],
    [ "start_intensity", "class_ray_properties.html#a5c8cf4cd27b861311091b1303a282276", null ]
];