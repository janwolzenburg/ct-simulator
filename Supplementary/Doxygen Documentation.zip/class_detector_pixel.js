var class_detector_pixel =
[
    [ "DetectorPixel", "class_detector_pixel.html#abf9e0cb35dcc3e9a4cb4ca9a76a92547", null ],
    [ "DetectorPixel", "class_detector_pixel.html#ab6ada2a6b2b6cd7d5cbd36620dc607aa", null ],
    [ "AddDetectedRayProperties", "class_detector_pixel.html#a1c01c0449ebca6aeb2ffdd36217aa52b", null ],
    [ "ConvertTo", "class_detector_pixel.html#aa1e79e43359b43dd064592ab342de267", null ],
    [ "detected_ray_properties", "class_detector_pixel.html#afc6af91e7d086a3b615d8a67eb5817a0", null ],
    [ "GetProjectionValue", "class_detector_pixel.html#a288923e4edd7d14c066205ab310f2166", null ],
    [ "NormalLine", "class_detector_pixel.html#a460f8bd5465cd54da19c501602e56071", null ],
    [ "ResetDetectedRayProperties", "class_detector_pixel.html#a7a450bf7d870563643a14fbf75d40e68", null ]
];