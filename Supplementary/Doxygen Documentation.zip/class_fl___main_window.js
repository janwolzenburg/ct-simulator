var class_fl___main_window =
[
    [ "Fl_MainWindow", "class_fl___main_window.html#a0ffa38056d27fdd45942adcd9ed0e179", null ],
    [ "CreateModel", "class_fl___main_window.html#aaa44b5795c7a2492154027a86fed6e87", null ],
    [ "ImportProjections", "class_fl___main_window.html#a5645b4054c1ae38ce4ecf9fa61c20b13", null ],
    [ "SetResetAtExit", "class_fl___main_window.html#a58c19346216a54cee4f9d74430b7a1ed", null ],
    [ "author_name_", "class_fl___main_window.html#a67c140e8fd9abdb2e4d0cd2e20ba3100", null ],
    [ "create_model_callback_", "class_fl___main_window.html#aeb1b117d2584feea94bb6bc7f04e4e65", null ],
    [ "creator_windows_", "class_fl___main_window.html#a0f2b60dae2fb54b6ac580b8dc650eb2c", null ],
    [ "gantry_creation_", "class_fl___main_window.html#a47146a0e0296bf12fe85a2daf9057c37", null ],
    [ "git_repository_", "class_fl___main_window.html#a26c9cd56174fd8125d4130142e846961", null ],
    [ "import_projections_button_", "class_fl___main_window.html#a18169a850fc3602efb8b5b779530508e", null ],
    [ "import_projections_callback_", "class_fl___main_window.html#aad78111319e1c982dd3015668b7f5d47", null ],
    [ "import_projections_file_chooser_", "class_fl___main_window.html#a655317f7601f0bcbf04e4ddc180788e4", null ],
    [ "menu_group_", "class_fl___main_window.html#a55797e022e510b28526934625cb09d72", null ],
    [ "model_creator_button_", "class_fl___main_window.html#ad7b633df8e2ebe2d46799baf9394dd05", null ],
    [ "model_view_", "class_fl___main_window.html#a47b632114f4d5b021c773fea49157305", null ],
    [ "reset_program_state_at_exit_button_", "class_fl___main_window.html#a37a13abc164b0e3a79aaff9faf6ed13e", null ],
    [ "reset_program_state_callback_", "class_fl___main_window.html#aec0079707ea3cf21527ec511a1bd33fc", null ],
    [ "tomography_execution_", "class_fl___main_window.html#acfd8a5fc12208ab33c2ede9361c1939a", null ]
];