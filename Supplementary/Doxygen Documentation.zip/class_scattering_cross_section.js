var class_scattering_cross_section =
[
    [ "ScatteringCrossSection", "class_scattering_cross_section.html#a7b02a47f708074acf352aa3ad63ef8fb", null ],
    [ "GetCrossSection", "class_scattering_cross_section.html#aa3b08ccf9e570b2cd0a0c41ae508dd92", null ],
    [ "GetCrossSections", "class_scattering_cross_section.html#aa447a775ebd07205e3e7e2d72a201cf9", null ],
    [ "operator=", "class_scattering_cross_section.html#aeefed3d0881f5415784ea02b50347788", null ]
];