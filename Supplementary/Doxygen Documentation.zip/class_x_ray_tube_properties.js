var class_x_ray_tube_properties =
[
    [ "Material", "class_x_ray_tube_properties.html#a562173cce0c5c6afc18fbe755fbc0d71", [
      [ "Copper", "class_x_ray_tube_properties.html#a562173cce0c5c6afc18fbe755fbc0d71adf90b567ebfefb255504a44bc6e81f0b", null ],
      [ "Molybdenum", "class_x_ray_tube_properties.html#a562173cce0c5c6afc18fbe755fbc0d71afd6f76d5b0bda6a0fa354c2590beda9d", null ],
      [ "Thungsten", "class_x_ray_tube_properties.html#a562173cce0c5c6afc18fbe755fbc0d71a4d2e5bc718891b9ae93241eb3280e5e0", null ]
    ] ],
    [ "XRayTubeProperties", "class_x_ray_tube_properties.html#a505cadd1a52d77162537f25f8a6e1e75", null ],
    [ "XRayTubeProperties", "class_x_ray_tube_properties.html#a1541a6ed3eab87d1c2b31069ea8c8382", null ],
    [ "XRayTubeProperties", "class_x_ray_tube_properties.html#a5701b62cb97988db93ed024859c99941", null ],
    [ "Serialize", "class_x_ray_tube_properties.html#ac893548f36db7d4acf3be2346fc95a23", null ],
    [ "anode_current_A", "class_x_ray_tube_properties.html#a8960be106a5e4a97e4fa65e29b3e3a48", null ],
    [ "anode_material", "class_x_ray_tube_properties.html#addeb2191909cd1598933eb8661e1205b", null ],
    [ "anode_voltage_V", "class_x_ray_tube_properties.html#ad4118cdd619cd72542a35995aeb94d6e", null ],
    [ "filter_cut_of_energy", "class_x_ray_tube_properties.html#ab8625a300666344e2d5df552825722c9", null ],
    [ "filter_gradient", "class_x_ray_tube_properties.html#a894c79e969bebd6f30b54db0b94065e2", null ],
    [ "has_filter_", "class_x_ray_tube_properties.html#af45c2674fae72dc130731058ba5c005e", null ],
    [ "number_of_rays_per_pixel_", "class_x_ray_tube_properties.html#a879c9cf20760e66690ae1ca506b86cd1", null ],
    [ "spectral_energy_resolution", "class_x_ray_tube_properties.html#a0fb773ab4b3c05d5a29e58653567e639", null ]
];