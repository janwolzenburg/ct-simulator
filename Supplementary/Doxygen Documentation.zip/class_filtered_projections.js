var class_filtered_projections =
[
    [ "FilteredProjections", "class_filtered_projections.html#ab573e5756463d8f366457779eea9533c", null ],
    [ "FilteredProjections", "class_filtered_projections.html#a015ccd9860736cafc0fdc3267bc19bb3", null ],
    [ "FilteredProjections", "class_filtered_projections.html#afdaea541f65c5abf4013ba4c0451ed48", null ],
    [ "data_grid", "class_filtered_projections.html#a44210030fdb8dcc725f3e20c8591ef2a", null ],
    [ "filter", "class_filtered_projections.html#a45412e0a7a70aa799b8ad551401ec4c7", null ],
    [ "GetValue", "class_filtered_projections.html#a8a4af98902e370c0aae76a881e3b7a1c", null ],
    [ "resolution", "class_filtered_projections.html#abc50327994076bcae67de3cdf7b05a53", null ],
    [ "Serialize", "class_filtered_projections.html#a581850cb39422569fac2ca4ea8cc1e6d", null ],
    [ "size", "class_filtered_projections.html#a7ae27767e8a6ac6662d3537865d95c59", null ],
    [ "start", "class_filtered_projections.html#afb7661fbc1afd3acead1035299de5580", null ]
];