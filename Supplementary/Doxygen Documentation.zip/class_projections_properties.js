var class_projections_properties =
[
    [ "ProjectionsProperties", "class_projections_properties.html#a81493cf870ab5ad6669814545ec22410", null ],
    [ "ProjectionsProperties", "class_projections_properties.html#a26034e5bf2a6887dd9719d8c46c46c69", null ],
    [ "ProjectionsProperties", "class_projections_properties.html#a05dfd89ba60ee3de5ea781b812de15ef", null ],
    [ "angles_resolution", "class_projections_properties.html#aef8a8df0d948a2fc483cd1755e68562a", null ],
    [ "distances_resolution", "class_projections_properties.html#ad37b7aa8ae1f52262fb43ea7de02c019", null ],
    [ "GetTransformationResolution", "class_projections_properties.html#a1c95d791f759c90d1068a2b56acaff13", null ],
    [ "GetTransformationSize", "class_projections_properties.html#ab2782a233171cf7342b36fae307778f2", null ],
    [ "measuring_field_size", "class_projections_properties.html#a3bf9abc26eff205c03a89842580ad37a", null ],
    [ "number_of_distances", "class_projections_properties.html#ac9e19dc92b8ce5f1bcb968e2b720c155", null ],
    [ "number_of_frames_to_fill", "class_projections_properties.html#a79cb33d6f82c15370b176e5e3bd27ef7", null ],
    [ "number_of_projections", "class_projections_properties.html#a36011ea374211741c89827bbbfb1b734", null ],
    [ "Serialize", "class_projections_properties.html#ad146a20e8510fd485dfd885ba12bf273", null ]
];