var class_plot =
[
    [ "Plot", "class_plot.html#a520b777169193d96e001939e017d61a9", null ],
    [ "Plot", "class_plot.html#a7c56b5724e8665fcda0c111614b338ee", null ],
    [ "DrawPlot", "class_plot.html#abff792571e9e225f6a19ae1fa5088d5c", null ],
    [ "image_path", "class_plot.html#a0723b54d6d999130686f131b7b6b355a", null ],
    [ "image_size", "class_plot.html#ac67813ad0e05d98db55aed138e242fd6", null ],
    [ "Initialise", "class_plot.html#a65850ffafbeaf1796ba6c4d92331e547", null ],
    [ "redraw", "class_plot.html#a7d86d87e2991a1ebf0c3609599fc2519", null ],
    [ "reset", "class_plot.html#a63eff8833b26dbdf45d738961adcde54", null ],
    [ "SetLimits", "class_plot.html#a4c3b7bb4278d6f1a470b12da65d1fd52", null ],
    [ "SetSize", "class_plot.html#a7c883768225e9fcf2d3bd03b0a2f387e", null ],
    [ "are_axis_equal_", "class_plot.html#a0793f12d6f45f5f8e06ef6adfd6de8f6", null ],
    [ "enable_grid_", "class_plot.html#a557559532d25a8e5e4b1f46bdc6d3565", null ],
    [ "image_path_", "class_plot.html#ae99dfeea2f5bbc0774911324a5e7c60d", null ],
    [ "image_size_", "class_plot.html#a4c54493e1bb75a128af7ede3e964de9e", null ],
    [ "label_", "class_plot.html#abb7fec7f92718bca59dd0735ca69f992", null ],
    [ "limits_", "class_plot.html#a912668d62114c6f3433bf7bb1a6e2268", null ],
    [ "plot_2D_", "class_plot.html#a4afc2de2a75daf708f6c7d834ee0ddab", null ],
    [ "x_format_", "class_plot.html#abbc02d5759a4caf011b5fe384d1a437b", null ],
    [ "x_label_", "class_plot.html#a3861be8262ec378daccabb8f4b0ef1d0", null ],
    [ "y_format_", "class_plot.html#ae413dc3a00aefc7d69ba6e0b56f27495", null ],
    [ "y_label_", "class_plot.html#a5da5e8e0b5b1f5cd341fdee538f132d3", null ]
];