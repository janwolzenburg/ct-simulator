var class_model_view_properties =
[
    [ "ModelViewProperties", "class_model_view_properties.html#ab1cd02bbfd1873e1fe1c3f7229ec8960", null ],
    [ "ModelViewProperties", "class_model_view_properties.html#aab6c5a34c2618c5cd4aafeb0de09e88b", null ],
    [ "Serialize", "class_model_view_properties.html#ae9eed718ddc27f91f60b615509356165", null ],
    [ "artefact_impact", "class_model_view_properties.html#a51d4c6ba035462116817beb8d4283039", null ],
    [ "contrast", "class_model_view_properties.html#a254ccb088f9713124d0e3368c7eea783", null ],
    [ "slice_plane", "class_model_view_properties.html#a5faa9c365618c37741b29360636a18ce", null ]
];