var class_backprojection_filter =
[
    [ "TYPE", "class_backprojection_filter.html#ade6451f2da0153b5bdc9dc4ca8d3b302", [
      [ "ramLak", "class_backprojection_filter.html#ade6451f2da0153b5bdc9dc4ca8d3b302a0f02e66838270c31d7fcb1c38a05a9bd", null ],
      [ "sheppLogan", "class_backprojection_filter.html#ade6451f2da0153b5bdc9dc4ca8d3b302ac9e2fcba115c54b3659b1557efb55575", null ],
      [ "constant", "class_backprojection_filter.html#ade6451f2da0153b5bdc9dc4ca8d3b302a36b2c4e179f16ebaf39dfd67ed474fcc", null ]
    ] ],
    [ "BackprojectionFilter", "class_backprojection_filter.html#ada5cac4696e2a5f5ff75e7802335de2d", null ],
    [ "BackprojectionFilter", "class_backprojection_filter.html#aa08e79b1097b2036fac0a33a0f610c37", null ],
    [ "GetPlotValues", "class_backprojection_filter.html#aaf3352687ff51f0a3d783a2d89832de6", null ],
    [ "GetRelevantRange", "class_backprojection_filter.html#a8bc7ca992fa120b1508be7052c48688a", null ],
    [ "Normalise", "class_backprojection_filter.html#a57e8a1349efbbcee36e8ee9acbab2f61", null ],
    [ "operator()", "class_backprojection_filter.html#aac4646d58be5bde549238c3690d49fac", null ],
    [ "points_range", "class_backprojection_filter.html#a240d0686f2fbbfde1995771bed576e3b", null ],
    [ "type", "class_backprojection_filter.html#aae6c4c1416e1cd9869a8ab4c1f13b921", null ],
    [ "values", "class_backprojection_filter.html#a8d3d200d937a1c6e9ee331076ec36cb3", null ]
];