var class_simulation_properties =
[
    [ "SimulationProperties", "class_simulation_properties.html#a803bcab2debe344a25cd2fd05229e5f0", null ],
    [ "SimulationProperties", "class_simulation_properties.html#a282d91dd45f1d81c7f0a7f5e5fb1ac8c", null ],
    [ "SimulationProperties", "class_simulation_properties.html#a827c572d7f86a0eb2e29f5435da9e193", null ],
    [ "Serialize", "class_simulation_properties.html#af9013a7190018494691e29d4d3d70d33", null ],
    [ "bins_per_energy", "class_simulation_properties.html#a0dee755cac810d593d5a319896657d4a", null ],
    [ "number_of_energies_for_scattering", "class_simulation_properties.html#a0c7fbb9507d1ad9b8c687f3be7cad427", null ],
    [ "number_of_points_in_spectrum", "class_simulation_properties.html#a0651fc63953af1c6b7520b5b93637eac", null ],
    [ "number_of_scatter_angles", "class_simulation_properties.html#aaa3143a6c616837a21ce44948af8293e", null ],
    [ "quality", "class_simulation_properties.html#ac0607c804ad19bd2dee16750d2fcb9e2", null ],
    [ "ray_step_size_mm", "class_simulation_properties.html#afcbd070ec8af052b3f2520413509223d", null ]
];