var class_system_of_equations_solution =
[
    [ "SystemOfEquationsSolution", "class_system_of_equations_solution.html#a0449a7d6d620ddf06f8629be56677b1f", null ],
    [ "SystemOfEquationsSolution", "class_system_of_equations_solution.html#a51feb1313bb8583e51492a67e447882d", null ],
    [ "ConvertToString", "class_system_of_equations_solution.html#a471cd94dfbd7121bc41d42c0a7149825", null ],
    [ "GetVariableValue", "class_system_of_equations_solution.html#ae00a766c3e4cfe241b8380e59ea521e8", null ],
    [ "number_of_variables", "class_system_of_equations_solution.html#a6712a963c4a630e24431f663a983427b", null ],
    [ "SetVariableValue", "class_system_of_equations_solution.html#a7146265acb2f05a1a37e73c79b63c2b7", null ],
    [ "solution_found", "class_system_of_equations_solution.html#af7e1d638a8035a339b41b61a364018ea", null ],
    [ "solution_found", "class_system_of_equations_solution.html#a73ba5fb5409f6c9ce2fba1872ec632d6", null ]
];