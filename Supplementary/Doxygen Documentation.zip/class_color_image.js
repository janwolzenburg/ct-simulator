var class_color_image =
[
    [ "ColorImage", "class_color_image.html#a1212c33022885a46791f1d298eb74978", null ],
    [ "ColorImage", "class_color_image.html#a8c2464d1c310e974484cce4b9d5b0af5", null ],
    [ "ColorImage", "class_color_image.html#af13ed7c90f6603931dda13ee3223ec4c", null ],
    [ "ColorImage", "class_color_image.html#aa1456e6a08f6336e10a1b6840c212815", null ],
    [ "ColorImage", "class_color_image.html#a1453b3ec08a7a4d24000b5bdd99031ce", null ],
    [ "GetImageData", "class_color_image.html#a7b6c4b895f2b63b3c604bfa01d5266bb", null ],
    [ "GetIndex", "class_color_image.html#af48e6fd7c5c279726eb2abe8475b2d37", null ],
    [ "GetPixelData", "class_color_image.html#a8888128229f90d2aa85ee3539ae32456", null ],
    [ "height", "class_color_image.html#a25592687102fd5a366a1a9a33619e0ff", null ],
    [ "number_of_pixel", "class_color_image.html#a41448f4816ba6026d4fb9e6e0257f840", null ],
    [ "Serialize", "class_color_image.html#acc890940dfadb84e6ec4f26174e8625d", null ],
    [ "width", "class_color_image.html#a33d19ec116f6597fcc5a18197980f0da", null ]
];