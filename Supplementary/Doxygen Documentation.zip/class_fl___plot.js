var class_fl___plot =
[
    [ "Fl_Plot", "class_fl___plot.html#af2a3fa74cf4d37bcd1757a6ee4e4aaa1", null ],
    [ "AssignData", "class_fl___plot.html#ab31336f9157eed6e380ef06764bd68f4", null ],
    [ "CalculateScaled", "class_fl___plot.html#aa08a29de27daf3ef905765650d10f38d", null ],
    [ "draw", "class_fl___plot.html#af6eec0559093b1e8748dbe6f7c0c67a1", null ],
    [ "Initialise", "class_fl___plot.html#aeafbea8e98a6056c84a5619de05b3e48", null ],
    [ "plot", "class_fl___plot.html#a6d0afa83daf2773b238f9ac9dbcc516b", null ],
    [ "resize", "class_fl___plot.html#a97e8050dc16b9fdbcd8fa4fdbb258cd6", null ],
    [ "SetLimits", "class_fl___plot.html#a540f2debce245a48a2f8858462caefda", null ]
];