var class_matrix =
[
    [ "Matrix", "class_matrix.html#aa084a20f8670ed0abc24ecae49cc0d12", null ],
    [ "ConvertToString", "class_matrix.html#a6bf46d760fa6d492cd782772043f88f6", null ],
    [ "FindMaximum", "class_matrix.html#af6119f5a17d6e458ed74e8701ff41d81", null ],
    [ "number_of_columns", "class_matrix.html#a43d50611e5e6a20d1f9f45e08bee09b2", null ],
    [ "number_of_rows", "class_matrix.html#a8c33bd92e2d72f637d705920762a0586", null ],
    [ "operator()", "class_matrix.html#a888c60ebe63a851ba5351aba8ca58636", null ],
    [ "operator()", "class_matrix.html#a89456867a0456ff0ade6b76ebd50ffed", null ],
    [ "operator()", "class_matrix.html#aea4cc559f7e985e57df536d77a746783", null ],
    [ "operator()", "class_matrix.html#ace8470423e96c58461a4581c7e83023e", null ],
    [ "ScaleRow", "class_matrix.html#ae99e9a9708d10e65643baf03f9fc2365", null ],
    [ "SubstractRows", "class_matrix.html#a170a2576146b67a567f67f0ce2adf708", null ],
    [ "SwapColumns", "class_matrix.html#a4c5ddef963d6692da208cb45b3491b26", null ],
    [ "SwapRows", "class_matrix.html#adcf110fae5dc17462a868146d24e3273", null ],
    [ "data_", "class_matrix.html#aa9182feab706b8ad7893d2424c6161da", null ],
    [ "number_of_columns_", "class_matrix.html#aaaa3de7a59385d03f706136e7e20c232", null ],
    [ "number_of_rows_", "class_matrix.html#af13b234353b3e8ee322318969695a793", null ]
];