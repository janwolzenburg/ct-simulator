var class_x_ray_tube =
[
    [ "XRayTube", "class_x_ray_tube.html#ab6ed90098ac6cb816ea79cf05d8dba20", null ],
    [ "coordinate_system", "class_x_ray_tube.html#a36b9475044ee7af6e02cabd559be0616", null ],
    [ "GetElectricalPower", "class_x_ray_tube.html#af54996f88408a18a96d0a1b8e5cb868b", null ],
    [ "GetEmittedBeam", "class_x_ray_tube.html#a6cbd69cea01903e47f95ad1e8fd2a523", null ],
    [ "GetEmittedBeamPower", "class_x_ray_tube.html#a86b2c0f970592ae539321d171df920e2", null ],
    [ "GetEmittedEnergy", "class_x_ray_tube.html#a248f5cc776e6c438f0aa4fb2247c1b23", null ],
    [ "GetEmittedEnergyRange", "class_x_ray_tube.html#aa4f38ef5ecb723ccf4f5fa66a32cd6c7", null ],
    [ "GetEnergySpectrumPoints", "class_x_ray_tube.html#a20c54e22a922039b6b4eb5154bfe4d7d", null ],
    [ "GetMeanEnergy", "class_x_ray_tube.html#a1d32e2b7ad8d05ebb394743f068a4a05", null ],
    [ "GetSpectralEnergyResolution", "class_x_ray_tube.html#ad2c97ff73d933f11bb9d2bcbc7883216", null ],
    [ "number_of_rays_per_pixel", "class_x_ray_tube.html#a6dcbce0061e1aaf4d2d1f58f21c90684", null ],
    [ "properties", "class_x_ray_tube.html#a421f036b02c38a9df9fc6875517c110c", null ],
    [ "UpdateProperties", "class_x_ray_tube.html#ad1216843ed18b3be1c249dfe87ca7ab5", null ]
];