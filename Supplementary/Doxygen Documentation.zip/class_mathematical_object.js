var class_mathematical_object =
[
    [ "MathError", "class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858", [
      [ "Ok", "class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858aa60852f204ed8028c1c58808b746d115", null ],
      [ "General", "class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858a0db377921f4ce762c62526131097968f", null ],
      [ "Operation", "class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858a2a78ed76450c3cb42320882b3e055b31", null ],
      [ "Bounds", "class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858aac2e45cbad41f61cf0df36f61e367bfd", null ],
      [ "Input", "class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858a324118a6721dd6b8a9b9f4e327df2bf5", null ]
    ] ],
    [ "CheckForAndOutputError", "class_mathematical_object.html#a00b45d70d9174eccfb5cad572ca11c0a", null ],
    [ "CheckForAndOutputError", "class_mathematical_object.html#a68ec89191f81470f4859516594ffedee", null ],
    [ "ConvertToString", "class_mathematical_object.html#a922233ba1bc08d63b0fe90b825764eb4", null ],
    [ "Dump", "class_mathematical_object.html#a442d3ba7da5810f98f49f52301e50250", null ],
    [ "GetErrorString", "class_mathematical_object.html#a9fd98cd73f90f1441f6368f7bb5e4187", null ]
];