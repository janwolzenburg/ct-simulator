var class_projections =
[
    [ "Projections", "class_projections.html#af8dfe90115b6f25e79bed724d8b3ef98", null ],
    [ "Projections", "class_projections.html#acc7ec3ed646316a5944842143d4ac2f2", null ],
    [ "Projections", "class_projections.html#a433525e542715bef31ad981fa7a601ae", null ],
    [ "AssignData", "class_projections.html#acb9e80811322e11b24d3494ca513537d", null ],
    [ "AssignData", "class_projections.html#af0ce48b4fb2dbfaff96a58968fe904df", null ],
    [ "data", "class_projections.html#abe849e72bcfeee672858d11b6b35fe0e", null ],
    [ "GetData", "class_projections.html#a96941dc1a96f6f14cd6cdf48b6255995", null ],
    [ "max_value", "class_projections.html#a4e60bfda45da443275bfd3bd935e50df", null ],
    [ "properties", "class_projections.html#ab2b9799c7feed17dfe5aa43dc8e70de6", null ],
    [ "resolution", "class_projections.html#a05662ddd2547405fd851c89093d8aeb4", null ],
    [ "Serialize", "class_projections.html#a38eab022d23747880b99f8ed4583c479", null ],
    [ "size", "class_projections.html#ae40183646a0ff3b6373bdf16c4cd21f7", null ],
    [ "start", "class_projections.html#aba5ccd81caa7f52aabc9af66b160dbe2", null ],
    [ "tomography_properties", "class_projections.html#a45effb0ab237642aa878419d2aa89ea5", null ]
];