var class_voxel =
[
    [ "Face", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42", [
      [ "Begin", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a1a06729125544cab7cee73195fc044f0", null ],
      [ "YZ_Xp", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42acca6220f2d2957db9002734d4eceb323", null ],
      [ "XZ_Yp", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42aa442fba99489f461f28f459ed4054dcd", null ],
      [ "XY_Zp", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a65d14909b6190f2d265f9080005abcf8", null ],
      [ "XY_Zm", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42afeb984c9ddc8843ff8b92d53ee7151e2", null ],
      [ "XZ_Ym", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a49fa90eaa3d4afb5233c05cf3d56287a", null ],
      [ "YZ_Xm", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a7bfc328b81b6446ced6d5596ad311790", null ],
      [ "End", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a87557f11575c0ad78e4e28abedc13b6e", null ],
      [ "Invalid", "class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a4bbb8f967da6d1a610596d7257179c2b", null ]
    ] ],
    [ "Voxel", "class_voxel.html#a758cabd98005272767197e43fcdaf0e6", null ],
    [ "Voxel", "class_voxel.html#aab2cf291404c3a42b3841d287ad5788c", null ],
    [ "Contains", "class_voxel.html#aee7ad00348b750ca432b49e5ed7ab20f", null ],
    [ "ConvertToString", "class_voxel.html#a8382958c9a15cac64c40568a8e5c0c07", null ],
    [ "data", "class_voxel.html#a3085e68251bc061461340586b5ba2873", null ],
    [ "GetCenter", "class_voxel.html#a8da01118b63d9ebc93816b001573d4a6", null ],
    [ "GetFace", "class_voxel.html#af29855b0562ca8b110184758244a38c6", null ],
    [ "origin_corner", "class_voxel.html#aee16e7bed19102fb2a7f164ca5769781", null ],
    [ "size", "class_voxel.html#a42443fbfd1d358e68cb8c4d566019595", null ]
];