var class_ray_pixel_intersection =
[
    [ "RayPixelIntersection", "class_ray_pixel_intersection.html#a34018fbc38f9e02475a1a4041b7a7717", null ],
    [ "ray_properties", "class_ray_pixel_intersection.html#a4c043deee0ca1414ce82151416df935c", null ]
];