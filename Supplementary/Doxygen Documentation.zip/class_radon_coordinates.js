var class_radon_coordinates =
[
    [ "RadonCoordinates", "class_radon_coordinates.html#a413bfad6e06b329c3b83c65958e7f585", null ],
    [ "distance", "class_radon_coordinates.html#a8886f2fe676a19146ab173af9ede61a3", null ],
    [ "theta", "class_radon_coordinates.html#a2c40b4822c60b5d4fb1b3137d94200ce", null ]
];