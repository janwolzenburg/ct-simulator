var class_dot_plot =
[
    [ "CreatePlot", "class_dot_plot.html#aa32b50940b5b223d0825fcd6a143c546", null ]
];