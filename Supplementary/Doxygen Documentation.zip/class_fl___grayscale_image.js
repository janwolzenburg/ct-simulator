var class_fl___grayscale_image =
[
    [ "Fl_GrayscaleImage", "class_fl___grayscale_image.html#aaa7f39fb6164e3ce18f619497a81880a", null ],
    [ "AdjustContrast", "class_fl___grayscale_image.html#af91209cb02d1fa326446371d36c599dc", null ],
    [ "AssignImage", "class_fl___grayscale_image.html#a6588c0b71977e71396789a864149c8ec", null ],
    [ "AssignImage", "class_fl___grayscale_image.html#a2d1f3f9782f3150ada228a9ffd35de21", null ],
    [ "draw", "class_fl___grayscale_image.html#af997d909c50300b64eb416a7c3e16a9a", null ],
    [ "GetImageSize", "class_fl___grayscale_image.html#a6585080f45de00da7b724e7f21caea73", null ],
    [ "GetMaximum", "class_fl___grayscale_image.html#a7f8c02d7868ef1c356fb51d32ad085b1", null ],
    [ "GetMinimum", "class_fl___grayscale_image.html#a8102d97124c3199766a298cb34af1190", null ],
    [ "GetOriginalImageSize", "class_fl___grayscale_image.html#a1a2dcc9ac22a65cce0b786afc9655426", null ],
    [ "GetValue", "class_fl___grayscale_image.html#a4f22347be0a4f9949a9882f9bed64201", null ],
    [ "image_assigned", "class_fl___grayscale_image.html#a551bd8d35791a4c070ab1715f0461f3b", null ],
    [ "resize", "class_fl___grayscale_image.html#a83bff12e6f7ddf4584d3f55d99e82b9c", null ]
];