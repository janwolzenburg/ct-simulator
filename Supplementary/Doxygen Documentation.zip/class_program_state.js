var class_program_state =
[
    [ "~ProgramState", "class_program_state.html#a1f990f21a11cb9181e197b8b7382cffe", null ],
    [ "GetAbsolutePath", "class_program_state.html#a4887f3328c7980a8c55d3ca0e22766b1", null ],
    [ "reset_state_at_exit", "class_program_state.html#ac469b071790ca1e43341d4326a756b1a", null ],
    [ "SetResetStateAtExit", "class_program_state.html#ac047ac49997ac1f68352ce15faf42ea5", null ],
    [ "storage_path_", "class_program_state.html#af2d405ba18d5dcfbcc227eae78bbfaa2", null ]
];