var struct_index2_d =
[
    [ "x", "struct_index2_d.html#a9641b7f3b8dd51c3655cecb2ac5faf96", null ],
    [ "y", "struct_index2_d.html#a7c6844abf28d753e45259507b039a9a4", null ]
];