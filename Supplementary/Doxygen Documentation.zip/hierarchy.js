var hierarchy =
[
    [ "BackprojectionFilter", "class_backprojection_filter.html", null ],
    [ "C", null, [
      [ "PersistingObject< C >", "class_persisting_object.html", null ]
    ] ],
    [ "CallbackFunction< C >", "class_callback_function.html", null ],
    [ "CallbackFunction< Fl_GantryCreation >", "class_callback_function.html", null ],
    [ "CallbackFunction< Fl_MainWindow >", "class_callback_function.html", null ],
    [ "CallbackFunction< Fl_ModelCreator >", "class_callback_function.html", null ],
    [ "CallbackFunction< Fl_ModelView >", "class_callback_function.html", null ],
    [ "CallbackFunction< Fl_ProcessingWindow >", "class_callback_function.html", null ],
    [ "CallbackFunction< Fl_TomographyExecution >", "class_callback_function.html", null ],
    [ "ColorImage", "class_color_image.html", null ],
    [ "DataGrid< D >", "class_data_grid.html", [
      [ "Backprojection", "class_backprojection.html", [
        [ "PersistingObject< Backprojection >", "class_persisting_object.html", null ]
      ] ],
      [ "FilteredProjections", "class_filtered_projections.html", [
        [ "PersistingObject< FilteredProjections >", "class_persisting_object.html", null ]
      ] ],
      [ "Projections", "class_projections.html", [
        [ "PersistingObject< Projections >", "class_persisting_object.html", null ]
      ] ]
    ] ],
    [ "DataGrid< VoxelData >", "class_data_grid.html", null ],
    [ "DetectorProperties", "class_detector_properties.html", null ],
    [ "EnergySpectrum", "class_energy_spectrum.html", null ],
    [ "Fl_Group", null, [
      [ "Fl_BoundInput< Fl_Float_Input, double >", "class_fl___bound_input.html", null ],
      [ "Fl_BoundInput< Fl_Int_Input, size_t >", "class_fl___bound_input.html", null ],
      [ "Fl_BoundInput< Fl_Int_Input, int >", "class_fl___bound_input.html", null ],
      [ "Fl_BoundInput< Fl_Int_Input, unsigned int >", "class_fl___bound_input.html", null ],
      [ "Fl_AdjustableGrayscaleImage", "class_fl___adjustable_grayscale_image.html", null ],
      [ "Fl_BoundInput< C, T >", "class_fl___bound_input.html", null ],
      [ "Fl_GantryCreation", "class_fl___gantry_creation.html", null ],
      [ "Fl_GrayscaleImageWithAxis", "class_fl___grayscale_image_with_axis.html", null ],
      [ "Fl_ModelFeature", "class_fl___model_feature.html", null ],
      [ "Fl_ModelView", "class_fl___model_view.html", null ],
      [ "Fl_Selector", "class_fl___selector.html", null ],
      [ "Fl_TomographyExecution", "class_fl___tomography_execution.html", null ]
    ] ],
    [ "Fl_Native_File_Chooser", null, [
      [ "FileChooser", "class_file_chooser.html", [
        [ "PersistingObject< FileChooser >", "class_persisting_object.html", null ]
      ] ]
    ] ],
    [ "Fl_Widget", null, [
      [ "Fl_Plot< LinePlot >", "class_fl___plot.html", null ],
      [ "Fl_Plot< Geometryplot >", "class_fl___plot.html", null ],
      [ "Fl_Plot< DotPlot >", "class_fl___plot.html", null ],
      [ "Fl_GrayscaleImage", "class_fl___grayscale_image.html", [
        [ "Fl_GrayscaleImageWithAxis", "class_fl___grayscale_image_with_axis.html", null ]
      ] ],
      [ "Fl_Plot< P >", "class_fl___plot.html", null ]
    ] ],
    [ "Fl_Window", null, [
      [ "Fl_MainWindow", "class_fl___main_window.html", null ],
      [ "Fl_ModelCreator", "class_fl___model_creator.html", null ],
      [ "Fl_ProcessingWindow", "class_fl___processing_window.html", null ],
      [ "Fl_Progress_Window", "class_fl___progress___window.html", null ]
    ] ],
    [ "Gantry", "class_gantry.html", null ],
    [ "GrayscaleImage", "class_grayscale_image.html", null ],
    [ "GridCoordinates", "class_grid_coordinates.html", null ],
    [ "GridIndex", "class_grid_index.html", null ],
    [ "Index2D", "struct_index2_d.html", null ],
    [ "Index3D", "class_index3_d.html", null ],
    [ "MathematicalObject", "class_mathematical_object.html", [
      [ "LineSurfaceIntersection< Ray, DetectorPixel >", "class_line_surface_intersection.html", [
        [ "RayPixelIntersection", "class_ray_pixel_intersection.html", null ]
      ] ],
      [ "LineSurfaceIntersection< Ray, BoundedSurface >", "class_line_surface_intersection.html", null ],
      [ "CoordinateSystemTree", "class_coordinate_system_tree.html", null ],
      [ "Line", "class_line.html", [
        [ "Ray", "class_ray.html", null ]
      ] ],
      [ "LineSurfaceIntersection< L, S >", "class_line_surface_intersection.html", null ],
      [ "Matrix", "class_matrix.html", [
        [ "SystemOfEquations", "class_system_of_equations.html", null ]
      ] ],
      [ "Model", "class_model.html", [
        [ "PersistingObject< Model >", "class_persisting_object.html", null ]
      ] ],
      [ "PrimitiveCoordinateSystem", "class_primitive_coordinate_system.html", [
        [ "CoordinateSystem", "class_coordinate_system.html", null ]
      ] ],
      [ "PrimitiveVector3", "class_primitive_vector3.html", [
        [ "Coordinates", "class_coordinates.html", [
          [ "Vector3D", "class_vector3_d.html", [
            [ "Point3D", "class_point3_d.html", null ],
            [ "Unitvector3D", "class_unitvector3_d.html", null ]
          ] ]
        ] ]
      ] ],
      [ "Surface", "class_surface.html", [
        [ "BoundedSurface", "class_bounded_surface.html", [
          [ "DetectorPixel", "class_detector_pixel.html", null ]
        ] ]
      ] ],
      [ "SystemOfEquationsSolution", "class_system_of_equations_solution.html", null ],
      [ "Voxel", "class_voxel.html", null ]
    ] ],
    [ "ModelViewProperties", "class_model_view_properties.html", [
      [ "PersistingObject< ModelViewProperties >", "class_persisting_object.html", null ]
    ] ],
    [ "NaturalNumberRange", "class_natural_number_range.html", null ],
    [ "NumberRange", "class_number_range.html", null ],
    [ "PhysicalDetectorProperties", "struct_physical_detector_properties.html", [
      [ "PersistingObject< PhysicalDetectorProperties >", "class_persisting_object.html", null ]
    ] ],
    [ "PixelCoordinates", "struct_pixel_coordinates.html", null ],
    [ "Plot", "class_plot.html", [
      [ "Geometryplot", "class_geometryplot.html", null ],
      [ "LinePlot", "class_line_plot.html", [
        [ "DotPlot", "class_dot_plot.html", null ]
      ] ]
    ] ],
    [ "PlotLimits", "struct_plot_limits.html", null ],
    [ "ProgramState", "class_program_state.html", null ],
    [ "ProjectionsProperties", "class_projections_properties.html", [
      [ "PersistingObject< ProjectionsProperties >", "class_persisting_object.html", null ]
    ] ],
    [ "PropabilityDistribution", "class_propability_distribution.html", null ],
    [ "RadonCoordinates", "class_radon_coordinates.html", [
      [ "RadonPoint", "class_radon_point.html", null ]
    ] ],
    [ "RandomNumberGenerator", "class_random_number_generator.html", null ],
    [ "RayProperties", "class_ray_properties.html", null ],
    [ "RayScattering", "class_ray_scattering.html", null ],
    [ "RayVoxelIntersection", "class_ray_voxel_intersection.html", null ],
    [ "RGB", "struct_r_g_b.html", null ],
    [ "ScatteringCrossSection", "class_scattering_cross_section.html", null ],
    [ "SimulationProperties", "class_simulation_properties.html", null ],
    [ "SlicePlane", "class_slice_plane.html", null ],
    [ "Tomography", "class_tomography.html", null ],
    [ "TomographyProperties", "class_tomography_properties.html", [
      [ "PersistingObject< TomographyProperties >", "class_persisting_object.html", null ]
    ] ],
    [ "Tuple2D", "struct_tuple2_d.html", null ],
    [ "Tuple3D", "class_tuple3_d.html", [
      [ "PrimitiveVector3", "class_primitive_vector3.html", null ]
    ] ],
    [ "VoxelData", "class_voxel_data.html", null ],
    [ "XRayDetector", "class_x_ray_detector.html", null ],
    [ "XRayTube", "class_x_ray_tube.html", null ],
    [ "XRayTubeProperties", "class_x_ray_tube_properties.html", [
      [ "PersistingObject< XRayTubeProperties >", "class_persisting_object.html", null ]
    ] ]
];