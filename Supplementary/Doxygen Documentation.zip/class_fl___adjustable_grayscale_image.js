var class_fl___adjustable_grayscale_image =
[
    [ "Fl_AdjustableGrayscaleImage", "class_fl___adjustable_grayscale_image.html#a2eae959f9fa76d5004b80952d005869b", null ],
    [ "AssignImage", "class_fl___adjustable_grayscale_image.html#a6a931a6fe3d068a19a3775432d023662", null ],
    [ "AssignImage", "class_fl___adjustable_grayscale_image.html#a9efbf86c239669b7f556c5ee9fdb6cf6", null ],
    [ "ChangeSliderValues", "class_fl___adjustable_grayscale_image.html#a1122bac5d380e2e56daca3dbb08b119a", null ],
    [ "DidContrastChange", "class_fl___adjustable_grayscale_image.html#ad0fa6129ca2ab84843c5f2ea701c2c94", null ],
    [ "GetContrast", "class_fl___adjustable_grayscale_image.html#a5ea776fc9460f0b81f41df80d71227ea", null ],
    [ "handle", "class_fl___adjustable_grayscale_image.html#a71744f8175e5da7e25133169cc0fd0b5", null ],
    [ "image_assigned", "class_fl___adjustable_grayscale_image.html#a5441b2f5238b85d020b96272c57217b6", null ],
    [ "ResetBounds", "class_fl___adjustable_grayscale_image.html#ab2be0d58139f299aa8810fb2ba8a8fc4", null ],
    [ "SetAxis", "class_fl___adjustable_grayscale_image.html#aa7cddd7933aa9245266195cdacb90553", null ],
    [ "Setlabel", "class_fl___adjustable_grayscale_image.html#abd124f603824f2219fc5af9bbf94dc3c", null ],
    [ "SetSliderBounds", "class_fl___adjustable_grayscale_image.html#a88ee3041e3fb4367458afbce792be053", null ],
    [ "SetSliderBoundsFromImage", "class_fl___adjustable_grayscale_image.html#a3575cb0381aa08605be7a2fbab7bd12a", null ],
    [ "SetValueTip", "class_fl___adjustable_grayscale_image.html#a2cea33938978dfd825589d7f0244e864", null ]
];