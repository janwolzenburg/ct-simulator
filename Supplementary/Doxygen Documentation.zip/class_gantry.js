var class_gantry =
[
    [ "Gantry", "class_gantry.html#ab28af19d13847a4ca4fbff5741e70cfa", null ],
    [ "coordinate_system", "class_gantry.html#a7700d977560323f89419d8bb3697e6cc", null ],
    [ "detector", "class_gantry.html#a936539464ce0458377eeb03fd6ff7b1b", null ],
    [ "GetCenter", "class_gantry.html#a77ee2a7d6d1d89b302229cc1ebbc9611", null ],
    [ "pixel_array", "class_gantry.html#aa79fa02323c543815256ee06c1fc8a81", null ],
    [ "RadiateModel", "class_gantry.html#a6d1a3daa71498a27b29b6e5cfa63ca3b", null ],
    [ "ResetGantry", "class_gantry.html#a90678ab257dd49dd0aca88290cfffbc9", null ],
    [ "RotateCounterClockwise", "class_gantry.html#add6713debc4ca3a2135f1e159ecb0f94", null ],
    [ "TranslateInZDirection", "class_gantry.html#a43eb9c9965294a5d4c3ff91306744ec3", null ],
    [ "tube", "class_gantry.html#ac559700f91d69c16f372fe6dfb4675b5", null ],
    [ "UpdateTubeAndDetectorProperties", "class_gantry.html#a17627c065e5a5a6207407efe74b5e769", null ]
];