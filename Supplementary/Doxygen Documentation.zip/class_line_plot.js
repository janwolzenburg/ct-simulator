var class_line_plot =
[
    [ "LinePlot", "class_line_plot.html#ad80e469d90a00575eea813f3d8f626b7", null ],
    [ "LinePlot", "class_line_plot.html#afc50e007baf1488a936ade9eb238f9b3", null ],
    [ "AssignData", "class_line_plot.html#a4a69b826e366198ff1c64b8045918350", null ],
    [ "AssignData", "class_line_plot.html#af77853a915e2f254c7ed44cdbaae4082", null ],
    [ "CreatePlot", "class_line_plot.html#a0762cd2f6ccc3ed8f357c02fbbd7209f", null ],
    [ "x_values", "class_line_plot.html#a3e939238cea5bb0bec17847229549ffc", null ],
    [ "y_values", "class_line_plot.html#adaead80f33b6de4094f6910dd2d14118", null ]
];