var class_persisting_object =
[
    [ "PersistingObject", "class_persisting_object.html#a2cba12c0e76b20fa692deae773d9e254", null ],
    [ "PersistingObject", "class_persisting_object.html#a6a50ee4ef31676989ebb7f93b0c972e3", null ],
    [ "~PersistingObject", "class_persisting_object.html#a8ec4ebb4ba78e97c619d2630f1b24ef2", null ],
    [ "Load", "class_persisting_object.html#a55456c0d73fec1df953d4335736c4f46", null ],
    [ "operator=", "class_persisting_object.html#aa843c66221d1a0ed8a3030182c1bebdb", null ],
    [ "Save", "class_persisting_object.html#ab5f96ed3097e4d1f6dbc41425f9e015d", null ],
    [ "SetAsLoaded", "class_persisting_object.html#a3b26791e53609fe42e40d049a180df55", null ],
    [ "was_loaded", "class_persisting_object.html#af21b698698bbca87be3343a3c9bfb458", null ]
];