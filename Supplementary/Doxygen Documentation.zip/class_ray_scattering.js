var class_ray_scattering =
[
    [ "RayScattering", "class_ray_scattering.html#abf82f4e7907547cc40564591186fe86d", null ],
    [ "angle_resolution", "class_ray_scattering.html#a6adaae542242cce485e6db6782dbd5b9", null ],
    [ "GetRandomAngle", "class_ray_scattering.html#a7949e114d8064dc2218a53183b31feb9", null ],
    [ "max_angle_to_lie_in_plane", "class_ray_scattering.html#a5b0ea85edc28f8459bce30fd47ee6852", null ],
    [ "scattering_plane_normal", "class_ray_scattering.html#a88b85abea1de36bd468493c1a0f6af85", null ]
];