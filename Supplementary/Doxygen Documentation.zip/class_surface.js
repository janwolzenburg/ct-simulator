var class_surface =
[
    [ "Surface", "class_surface.html#a4ef7bf6883e1f10943720876bd227dc2", null ],
    [ "Surface", "class_surface.html#a963656464ad140473ed5ceded0eb8e60", null ],
    [ "Surface", "class_surface.html#a3b3ddf4701e0bb468a46254b12ab0c7a", null ],
    [ "AreParametersInBounds", "class_surface.html#a6ab41c77700eb6ce35016bc80eac98c6", null ],
    [ "ConvertTo", "class_surface.html#a90aa162cfbb7e77bd02791b7c46206f7", null ],
    [ "ConvertToString", "class_surface.html#a48ea6fcae2ed9c9c3e9ce809fe7ae82d", null ],
    [ "direction_1", "class_surface.html#a1de8d0a4e2b28fda6268f4ffe73ef152", null ],
    [ "direction_2", "class_surface.html#a3e3ef29202912c9e7398bafbcaae0e6d", null ],
    [ "GetNormal", "class_surface.html#a5cb5760312985db2a8857535effcffa0", null ],
    [ "GetPoint", "class_surface.html#abc59453810bfb2e4e0f05f1d90e9d68b", null ],
    [ "origin", "class_surface.html#a0695b97971988c4758f03e4315328dde", null ],
    [ "Serialize", "class_surface.html#ad1bcf2448337e15454501a70759da242", null ],
    [ "direction_1_", "class_surface.html#ae292c1ab1bae1d2804d33fea2a6cfabd", null ],
    [ "direction_2_", "class_surface.html#a9f65f9a8a82dfe4be1b20b1e8b12ea5f", null ],
    [ "normal_", "class_surface.html#a261821520ce21d9c0bb1e6cf29a0a961", null ],
    [ "origin_", "class_surface.html#a7d1fff6b6ae146a964cfae19fc599374", null ]
];