var class_coordinates =
[
    [ "Coordinates", "class_coordinates.html#a0d20d1da582ba89eeea1c9fd0dfb1903", null ],
    [ "Coordinates", "class_coordinates.html#a5003dcacff260b124fa2643a56ed8cf0", null ],
    [ "ConvertTo", "class_coordinates.html#aff53d6fd5b6921bd2b69842724c06bf4", null ],
    [ "ConvertToString", "class_coordinates.html#a3fbf3b6c64bc993531d30238485608d3", null ],
    [ "HasSameSystem", "class_coordinates.html#af06f7e131a308b7ba4cb874363b6cbc6", null ],
    [ "HasSameSystem", "class_coordinates.html#a79d540b37458cc0d58e11ad74f47a5fa", null ],
    [ "operator*", "class_coordinates.html#a3c96f1ba2561f703ee0770ffe8ad1d14", null ],
    [ "operator+", "class_coordinates.html#a9da43b5642bf726a605c99a80b24b815", null ],
    [ "operator-", "class_coordinates.html#ac98524eed7423287faa5fad455dc5d57", null ],
    [ "operator-", "class_coordinates.html#a4945a02cafe9477c3221dd3c95e39c14", null ],
    [ "operator/", "class_coordinates.html#a353abff6e2c7f67978118e41ceac7dc5", null ],
    [ "operator==", "class_coordinates.html#a27022ee758e6922cec55afc7e9afa2ef", null ],
    [ "coordinate_system_", "class_coordinates.html#a393632b8d083277926367d582f33a504", null ]
];