var class_random_number_generator =
[
    [ "RandomNumberGenerator", "class_random_number_generator.html#a718528e50d8f5dcced3ab45e84b6e5b2", null ],
    [ "DidARandomEventHappen", "class_random_number_generator.html#a915d014285e67af2bc60540f2554ce20", null ],
    [ "GetRandomNumber", "class_random_number_generator.html#ae9e224d268d62a0300a86fb988279f41", null ],
    [ "GetRandomShortNumber", "class_random_number_generator.html#a7aa250263c34b2a5d51a905da8c85c3c", null ]
];