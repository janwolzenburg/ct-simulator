var searchData=
[
  ['use_5fsimple_5fabsorption_0',['use_simple_absorption',['../class_tomography_properties.html#ab73de1c55a2aa2af9da5cbe970d555cc',1,'TomographyProperties']]]
];
