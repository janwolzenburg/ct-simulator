var searchData=
[
  ['tomography_0',['Tomography',['../class_tomography.html#a0e915f6d60713639b6daf9282966d44e',1,'Tomography::Tomography(const TomographyProperties properties)'],['../class_tomography.html#a64d9a7bc8b4653b5ccaf3bfeee400e9a',1,'Tomography::Tomography(void)']]],
  ['tomography_5fproperties_1',['tomography_properties',['../class_projections.html#a45effb0ab237642aa878419d2aa89ea5',1,'Projections']]],
  ['tomographyproperties_2',['TomographyProperties',['../class_tomography_properties.html#a59f88fe307b4b1b9ddc16f7ecf4c1ba5',1,'TomographyProperties::TomographyProperties(void)'],['../class_tomography_properties.html#a1d7c8e9300b54eb3ad0da45d3f1a4dc5',1,'TomographyProperties::TomographyProperties(const bool scattering_enabled, const size_t max_scattering_occurrences, const double scatter_propability_correction, const bool use_simple_absorption, const double scattered_ray_absorption_factor, const string name=&quot;Unnamed&quot;, const bool filter_active=false, const size_t simulation_quality=9)'],['../class_tomography_properties.html#a7efd9a84558ef4535c215c0a9fa52ef6',1,'TomographyProperties::TomographyProperties(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)']]],
  ['translate_3',['Translate',['../class_coordinate_system.html#a03597690bc3de17b14f6127d36ef1f93',1,'CoordinateSystem::Translate()'],['../class_primitive_coordinate_system.html#a7fc3d4e53fa852da71754becb59fcd2c',1,'PrimitiveCoordinateSystem::Translate()']]],
  ['translateinzdirection_4',['TranslateInZDirection',['../class_gantry.html#a43eb9c9965294a5d4c3ff91306744ec3',1,'Gantry']]],
  ['transmitray_5',['TransmitRay',['../class_model.html#a3a7e06894f14156d91c0218a4cfe2545',1,'Model']]],
  ['trydetection_6',['TryDetection',['../class_x_ray_detector.html#a131d56ae798c266e6b6a5f5d44db6aaa',1,'XRayDetector']]],
  ['tube_7',['tube',['../class_gantry.html#ac559700f91d69c16f372fe6dfb4675b5',1,'Gantry']]],
  ['tuple3d_8',['Tuple3D',['../class_tuple3_d.html#aef557b05a24f6534170a68abe7fdcc88',1,'Tuple3D::Tuple3D(const double x_, const double y_, const double z_)'],['../class_tuple3_d.html#a2624ba2f42f12034451a6e25cf956b32',1,'Tuple3D::Tuple3D(void)'],['../class_tuple3_d.html#a48e9fc1b89317138f48a2b05e0846604',1,'Tuple3D::Tuple3D(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)']]],
  ['type_9',['type',['../class_backprojection_filter.html#aae6c4c1416e1cd9869a8ab4c1f13b921',1,'BackprojectionFilter']]]
];
