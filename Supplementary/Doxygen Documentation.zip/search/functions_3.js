var searchData=
[
  ['data_0',['data',['../class_energy_spectrum.html#a1bf065f25b0277bfd2e865bc46db4e8b',1,'EnergySpectrum::data()'],['../class_projections.html#abe849e72bcfeee672858d11b6b35fe0e',1,'Projections::data()'],['../class_voxel.html#a3085e68251bc061461340586b5ba2873',1,'Voxel::data()']]],
  ['data_5fgrid_1',['data_grid',['../class_filtered_projections.html#a44210030fdb8dcc725f3e20c8591ef2a',1,'FilteredProjections']]],
  ['datagrid_2',['DataGrid',['../class_data_grid.html#a6f942d06cafb53e72ac3956ea35d917f',1,'DataGrid::DataGrid(void)'],['../class_data_grid.html#aef30a9d8b473718099f7712ee422dd29',1,'DataGrid::DataGrid(const GridIndex size, const GridCoordinates start, const GridCoordinates resolution, D default_value=D{})'],['../class_data_grid.html#a9db368c82fb2df1f52b294511fadbfc4',1,'DataGrid::DataGrid(const NumberRange column_range, const NumberRange row_range, const GridCoordinates resolution, D default_value=D{})'],['../class_data_grid.html#aae4cceff472ac7fc622f8bf281b917e6',1,'DataGrid::DataGrid(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)']]],
  ['definitely_5fhits_5fexpected_5fpixel_3',['definitely_hits_expected_pixel',['../class_ray_properties.html#a6a60972812b44d90ab743295200d767e',1,'RayProperties']]],
  ['detected_5fray_5fproperties_4',['detected_ray_properties',['../class_detector_pixel.html#afc6af91e7d086a3b615d8a67eb5817a0',1,'DetectorPixel']]],
  ['detector_5',['detector',['../class_gantry.html#a936539464ce0458377eeb03fd6ff7b1b',1,'Gantry']]],
  ['detectorpixel_6',['DetectorPixel',['../class_detector_pixel.html#abf9e0cb35dcc3e9a4cb4ca9a76a92547',1,'DetectorPixel::DetectorPixel(const BoundedSurface surface)'],['../class_detector_pixel.html#ab6ada2a6b2b6cd7d5cbd36620dc607aa',1,'DetectorPixel::DetectorPixel(const BoundedSurface surface, const vector&lt; RayProperties &gt; properties)']]],
  ['detectorproperties_7',['DetectorProperties',['../class_detector_properties.html#a57a3c3b31351ced87749f2aad8bbecef',1,'DetectorProperties']]],
  ['detectray_8',['DetectRay',['../class_x_ray_detector.html#aacc0b83b844b5ab44d1505a09804a952',1,'XRayDetector']]],
  ['didarandomeventhappen_9',['DidARandomEventHappen',['../class_random_number_generator.html#a915d014285e67af2bc60540f2554ce20',1,'RandomNumberGenerator']]],
  ['didcontrastchange_10',['DidContrastChange',['../class_fl___adjustable_grayscale_image.html#ad0fa6129ca2ab84843c5f2ea701c2c94',1,'Fl_AdjustableGrayscaleImage']]],
  ['direction_11',['direction',['../class_line.html#a7a5a5625c7c84b42bcf2e75404b5cfe2',1,'Line']]],
  ['direction_5f1_12',['direction_1',['../class_surface.html#a1de8d0a4e2b28fda6268f4ffe73ef152',1,'Surface']]],
  ['direction_5f2_13',['direction_2',['../class_surface.html#a3e3ef29202912c9e7398bafbcaae0e6d',1,'Surface']]],
  ['distances_5fresolution_14',['distances_resolution',['../class_projections_properties.html#ad37b7aa8ae1f52262fb43ea7de02c019',1,'ProjectionsProperties']]],
  ['draw_15',['draw',['../class_fl___grayscale_image.html#af997d909c50300b64eb416a7c3e16a9a',1,'Fl_GrayscaleImage::draw()'],['../class_fl___grayscale_image_with_axis.html#a997a53b2504ddac307d87cd460600a85',1,'Fl_GrayscaleImageWithAxis::draw()'],['../class_fl___plot.html#af6eec0559093b1e8748dbe6f7c0c67a1',1,'Fl_Plot::draw()']]],
  ['drawplot_16',['DrawPlot',['../class_plot.html#abff792571e9e225f6a19ae1fa5088d5c',1,'Plot']]],
  ['dump_17',['Dump',['../class_mathematical_object.html#a442d3ba7da5810f98f49f52301e50250',1,'MathematicalObject']]]
];
