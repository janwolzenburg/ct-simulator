var searchData=
[
  ['x_0',['x',['../struct_index2_d.html#a9641b7f3b8dd51c3655cecb2ac5faf96',1,'Index2D::x'],['../struct_tuple2_d.html#a6508967e8a067f88551c297bf633d7cb',1,'Tuple2D::x'],['../class_index3_d.html#a7f5e51cad29bbde8d215d7ad2cfb2e01',1,'Index3D::x'],['../class_tuple3_d.html#ac0bb3faec2736d6ed7edd187b89a9cbf',1,'Tuple3D::x'],['../struct_pixel_coordinates.html#a58e924179ebcbf15179a36f531d1253c',1,'PixelCoordinates::x']]],
  ['x_5fformat_5f_1',['x_format_',['../class_plot.html#abbc02d5759a4caf011b5fe384d1a437b',1,'Plot']]],
  ['x_5flabel_5f_2',['x_label_',['../class_plot.html#a3861be8262ec378daccabb8f4b0ef1d0',1,'Plot']]],
  ['x_5fvalues_3',['x_values',['../class_line_plot.html#a3e939238cea5bb0bec17847229549ffc',1,'LinePlot']]],
  ['xfactor_4',['xFactor',['../struct_plot_limits.html#aae3a3d257c0f72240e85817035c9f509',1,'PlotLimits']]],
  ['xrange_5',['xRange',['../struct_plot_limits.html#a26c85811b2eda83a9314bc3d3c6e48ba',1,'PlotLimits']]]
];
