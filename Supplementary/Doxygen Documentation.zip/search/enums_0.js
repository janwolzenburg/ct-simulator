var searchData=
[
  ['face_0',['Face',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42',1,'Voxel']]]
];
