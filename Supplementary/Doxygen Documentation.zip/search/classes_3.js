var searchData=
[
  ['energyspectrum_0',['EnergySpectrum',['../class_energy_spectrum.html',1,'']]]
];
