var searchData=
[
  ['scatter_5fpropability_5fcorrection_0',['scatter_propability_correction',['../class_tomography_properties.html#aea1e604807b1ea7902173636ab8bc9e6',1,'TomographyProperties']]],
  ['scattered_5fray_5fabsorption_5ffactor_1',['scattered_ray_absorption_factor',['../class_tomography_properties.html#aa5cd18ac5aa71818db5e07d3d96b0c47',1,'TomographyProperties']]],
  ['scattering_5fenabled_2',['scattering_enabled',['../class_tomography_properties.html#abef24d37822b08151eb157657df13020',1,'TomographyProperties']]],
  ['shape_5fnames_3',['shape_names',['../class_fl___model_feature.html#a517be260b13b3c8fb7c78133c04d4c9c',1,'Fl_ModelFeature']]],
  ['significance_5fpercentage_4',['significance_percentage',['../class_backprojection_filter.html#a775cebb91ce3d2fc010a63608c641b20',1,'BackprojectionFilter']]],
  ['simulation_5fquality_5',['simulation_quality',['../class_tomography_properties.html#aaafdbff9d7eaa99c2c664223e39732da',1,'TomographyProperties']]],
  ['slice_5fplane_6',['slice_plane',['../class_model_view_properties.html#a5faa9c365618c37741b29360636a18ce',1,'ModelViewProperties']]],
  ['special_5fproperty_5fnames_7',['special_property_names',['../class_voxel_data.html#a5c641463e8256ea8f4d6df8c5ee67c94',1,'VoxelData']]],
  ['spectral_5fenergy_5fresolution_8',['spectral_energy_resolution',['../class_x_ray_tube_properties.html#a0fb773ab4b3c05d5a29e58653567e639',1,'XRayTubeProperties']]],
  ['storage_5fpath_5f_9',['storage_path_',['../class_program_state.html#af2d405ba18d5dcfbcc227eae78bbfaa2',1,'ProgramState']]],
  ['surface_10',['surface',['../class_slice_plane.html#a62afae19b800e793aa93d011be0ee321',1,'SlicePlane']]],
  ['surface_5fparameter_5f1_5f_11',['surface_parameter_1_',['../class_line_surface_intersection.html#a6f110265dc12b013535a77c3f39446eb',1,'LineSurfaceIntersection']]],
  ['surface_5fparameter_5f2_5f_12',['surface_parameter_2_',['../class_line_surface_intersection.html#ab37b263befc8aba4ec08d6be68ed62d7',1,'LineSurfaceIntersection']]]
];
