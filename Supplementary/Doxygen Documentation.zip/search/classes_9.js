var searchData=
[
  ['naturalnumberrange_0',['NaturalNumberRange',['../class_natural_number_range.html',1,'']]],
  ['numberrange_1',['NumberRange',['../class_number_range.html',1,'']]]
];
