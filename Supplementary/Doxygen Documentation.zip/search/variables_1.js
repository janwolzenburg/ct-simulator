var searchData=
[
  ['background_5fcolor_0',['background_color',['../class_fl___grayscale_image.html#a78a110ad7b8313dca9760f1e5ccc7c9b',1,'Fl_GrayscaleImage']]],
  ['bins_5fper_5fenergy_1',['bins_per_energy',['../class_simulation_properties.html#a0dee755cac810d593d5a319896657d4a',1,'SimulationProperties']]],
  ['blue_2',['blue',['../struct_r_g_b.html#a233b293e05afb1f665bccf5e755a1015',1,'RGB']]]
];
