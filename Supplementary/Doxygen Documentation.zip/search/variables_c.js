var searchData=
[
  ['origin_5f_0',['origin_',['../class_line.html#af544443e6dea4d3a427597068d027cc7',1,'Line::origin_'],['../class_primitive_coordinate_system.html#ad221f1c200c595fefa07db4780ac3ba7',1,'PrimitiveCoordinateSystem::origin_'],['../class_surface.html#a7d1fff6b6ae146a964cfae19fc599374',1,'Surface::origin_']]]
];
