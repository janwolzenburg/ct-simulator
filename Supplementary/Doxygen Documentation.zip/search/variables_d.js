var searchData=
[
  ['plot_5f2d_5f_0',['plot_2D_',['../class_plot.html#a4afc2de2a75daf708f6c7d834ee0ddab',1,'Plot']]],
  ['position_5fz_1',['position_z',['../class_slice_plane.html#a4962c2920a783f73a50b8537f6ccc8d4',1,'SlicePlane']]]
];
