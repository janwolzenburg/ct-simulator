var searchData=
[
  ['name_0',['name',['../class_tomography_properties.html#a2cd272b6a28e6c825ce4a74204ece48e',1,'TomographyProperties']]],
  ['normal_5f_1',['normal_',['../class_surface.html#a261821520ce21d9c0bb1e6cf29a0a961',1,'Surface']]],
  ['number_5fof_5fcolumns_5f_2',['number_of_columns_',['../class_matrix.html#aaaa3de7a59385d03f706136e7e20c232',1,'Matrix']]],
  ['number_5fof_5fenergies_5ffor_5fscattering_3',['number_of_energies_for_scattering',['../class_simulation_properties.html#a0c7fbb9507d1ad9b8c687f3be7cad427',1,'SimulationProperties']]],
  ['number_5fof_5fpixel_4',['number_of_pixel',['../class_detector_properties.html#aaa4aa3972f1f96c4cb8bc00b20a9ecc4',1,'DetectorProperties']]],
  ['number_5fof_5fpoints_5fin_5fspectrum_5',['number_of_points_in_spectrum',['../class_simulation_properties.html#a0651fc63953af1c6b7520b5b93637eac',1,'SimulationProperties']]],
  ['number_5fof_5frays_5fper_5fpixel_5f_6',['number_of_rays_per_pixel_',['../class_x_ray_tube_properties.html#a879c9cf20760e66690ae1ca506b86cd1',1,'XRayTubeProperties']]],
  ['number_5fof_5frows_5f_7',['number_of_rows_',['../class_matrix.html#af13b234353b3e8ee322318969695a793',1,'Matrix']]],
  ['number_5fof_5fscatter_5fangles_8',['number_of_scatter_angles',['../class_simulation_properties.html#aaa3143a6c616837a21ce44948af8293e',1,'SimulationProperties']]]
];
