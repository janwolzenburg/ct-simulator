var searchData=
[
  ['has_5fanti_5fscattering_5fstructure_0',['has_anti_scattering_structure',['../struct_physical_detector_properties.html#ac4e863075f4c253f59638ecd3a6a956a',1,'PhysicalDetectorProperties::has_anti_scattering_structure'],['../class_detector_properties.html#a7aab5912a9c2abc184aa59f49cddb72c',1,'DetectorProperties::has_anti_scattering_structure']]],
  ['has_5ffilter_5f_1',['has_filter_',['../class_x_ray_tube_properties.html#af45c2674fae72dc130731058ba5c005e',1,'XRayTubeProperties']]]
];
