var searchData=
[
  ['name_0',['name',['../class_model.html#a0a6cdbe77c4f4400ff47c15cd8146c43',1,'Model']]],
  ['naturalnumberrange_1',['NaturalNumberRange',['../class_natural_number_range.html#ab1521ec985e0d27559c00735c7c1a6d3',1,'NaturalNumberRange']]],
  ['negatexcomponent_2',['NegateXComponent',['../class_vector3_d.html#a7d6ab15c5cda95b14a9f81b7d7e641df',1,'Vector3D']]],
  ['normalise_3',['Normalise',['../class_backprojection_filter.html#a57e8a1349efbbcee36e8ee9acbab2f61',1,'BackprojectionFilter::Normalise()'],['../class_primitive_vector3.html#a70624b0d7014224c73bf571a3d203e4d',1,'PrimitiveVector3::Normalise()'],['../class_vector3_d.html#a2ec9f6e137f05ac0366f20229a8fb530',1,'Vector3D::Normalise()']]],
  ['normalline_4',['NormalLine',['../class_detector_pixel.html#a460f8bd5465cd54da19c501602e56071',1,'DetectorPixel']]],
  ['number_5fof_5fcolumns_5',['number_of_columns',['../class_matrix.html#a43d50611e5e6a20d1f9f45e08bee09b2',1,'Matrix']]],
  ['number_5fof_5fdistances_6',['number_of_distances',['../class_projections_properties.html#ac9e19dc92b8ce5f1bcb968e2b720c155',1,'ProjectionsProperties']]],
  ['number_5fof_5fframes_5fto_5ffill_7',['number_of_frames_to_fill',['../class_projections_properties.html#a79cb33d6f82c15370b176e5e3bd27ef7',1,'ProjectionsProperties']]],
  ['number_5fof_5flines_8',['number_of_lines',['../class_fl___progress___window.html#a4a17f467e9816a2cd58b9b23887448a5',1,'Fl_Progress_Window']]],
  ['number_5fof_5fpixel_9',['number_of_pixel',['../class_color_image.html#a41448f4816ba6026d4fb9e6e0257f840',1,'ColorImage::number_of_pixel()'],['../class_grayscale_image.html#a56301d65055b69bd75ead1ce4864c4d1',1,'GrayscaleImage::number_of_pixel()']]],
  ['number_5fof_5fprojections_10',['number_of_projections',['../class_projections_properties.html#a36011ea374211741c89827bbbfb1b734',1,'ProjectionsProperties']]],
  ['number_5fof_5frays_5fper_5fpixel_11',['number_of_rays_per_pixel',['../class_x_ray_tube.html#a6dcbce0061e1aaf4d2d1f58f21c90684',1,'XRayTube']]],
  ['number_5fof_5frows_12',['number_of_rows',['../class_matrix.html#a8c33bd92e2d72f637d705920762a0586',1,'Matrix']]],
  ['number_5fof_5fvariables_13',['number_of_variables',['../class_system_of_equations_solution.html#a6712a963c4a630e24431f663a983427b',1,'SystemOfEquationsSolution']]],
  ['number_5fof_5fvoxel_5f3d_14',['number_of_voxel_3D',['../class_model.html#a5f163e20486dadf749e7dfcbd5084309',1,'Model']]],
  ['numberrange_15',['NumberRange',['../class_number_range.html#a179b1b07f6a82e2a5a0cfaf9490b88ae',1,'NumberRange::NumberRange(const double start, const double end)'],['../class_number_range.html#abfd43ea661a1cb8835f0b91872b2367d',1,'NumberRange::NumberRange(void)'],['../class_number_range.html#abc6f367991e447a92f129788b55a7e44',1,'NumberRange::NumberRange(const NaturalNumberRange &amp;natural_number_range)'],['../class_number_range.html#ac081c1975f71c6759cc476fbdadfa894',1,'NumberRange::NumberRange(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)']]]
];
