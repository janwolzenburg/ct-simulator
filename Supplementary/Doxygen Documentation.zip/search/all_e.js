var searchData=
[
  ['quality_0',['quality',['../class_simulation_properties.html#ac0607c804ad19bd2dee16750d2fcb9e2',1,'SimulationProperties']]]
];
