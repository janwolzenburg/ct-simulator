var searchData=
[
  ['matrix_0',['Matrix',['../class_matrix.html#aa084a20f8670ed0abc24ecae49cc0d12',1,'Matrix']]],
  ['max_5fangle_5fto_5flie_5fin_5fplane_1',['max_angle_to_lie_in_plane',['../class_ray_scattering.html#a5b0ea85edc28f8459bce30fd47ee6852',1,'RayScattering']]],
  ['max_5fvalue_2',['max_value',['../class_data_grid.html#a82a415f6707db23663598d0818d5da35',1,'DataGrid::max_value()'],['../class_projections.html#a4e60bfda45da443275bfd3bd935e50df',1,'Projections::max_value()']]],
  ['mean_5fenergy_3',['mean_energy',['../class_energy_spectrum.html#ab20e1b134c165e90a8ab998dcc771419',1,'EnergySpectrum']]],
  ['measuring_5ffield_5fsize_4',['measuring_field_size',['../class_projections_properties.html#a3bf9abc26eff205c03a89842580ad37a',1,'ProjectionsProperties']]],
  ['min_5fvalue_5',['min_value',['../class_data_grid.html#acc343c96e3a4a50ab65bf82a03df849d',1,'DataGrid']]],
  ['model_6',['Model',['../class_model.html#ac89761bd4a6cdff1de559e42ba02b613',1,'Model::Model(CoordinateSystem *const coordinate_system, const Index3D number_of_voxel_3D, const Tuple3D voxel_size, const string name, const VoxelData default_data=VoxelData{})'],['../class_model.html#acba63cbaae800f688283b651edc0fef2',1,'Model::Model(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)'],['../class_model.html#aa26cb9f39a3e0356152a57a2d2ecfaef',1,'Model::Model(void)']]],
  ['model_7',['model',['../class_fl___model_view.html#a8a9ef09c79841214062aa21614e2c6be',1,'Fl_ModelView']]],
  ['modelviewproperties_8',['ModelViewProperties',['../class_model_view_properties.html#ab1cd02bbfd1873e1fe1c3f7229ec8960',1,'ModelViewProperties::ModelViewProperties(void)'],['../class_model_view_properties.html#aab6c5a34c2618c5cd4aafeb0de09e88b',1,'ModelViewProperties::ModelViewProperties(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)']]],
  ['modify_9',['Modify',['../class_energy_spectrum.html#a10d9b312aecc6c816667e93fb1a8b656',1,'EnergySpectrum']]]
];
