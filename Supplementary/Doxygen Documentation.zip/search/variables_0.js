var searchData=
[
  ['anode_5fcurrent_5fa_0',['anode_current_A',['../class_x_ray_tube_properties.html#a8960be106a5e4a97e4fa65e29b3e3a48',1,'XRayTubeProperties']]],
  ['anode_5fmaterial_1',['anode_material',['../class_x_ray_tube_properties.html#addeb2191909cd1598933eb8661e1205b',1,'XRayTubeProperties']]],
  ['anode_5fvoltage_5fv_2',['anode_voltage_V',['../class_x_ray_tube_properties.html#ad4118cdd619cd72542a35995aeb94d6e',1,'XRayTubeProperties']]],
  ['arc_5fangle_3',['arc_angle',['../class_detector_properties.html#a22b44bc4387360eed6ae02e3b5ff97bf',1,'DetectorProperties']]],
  ['are_5faxis_5fequal_5f_4',['are_axis_equal_',['../class_plot.html#a0793f12d6f45f5f8e06ef6adfd6de8f6',1,'Plot']]],
  ['artefact_5fimpact_5',['artefact_impact',['../class_model_view_properties.html#a51d4c6ba035462116817beb8d4283039',1,'ModelViewProperties']]],
  ['author_5fname_5f_6',['author_name_',['../class_fl___main_window.html#a67c140e8fd9abdb2e4d0cd2e20ba3100',1,'Fl_MainWindow']]],
  ['autoxrange_7',['autoXRange',['../struct_plot_limits.html#ac5feb537b158bbafe7c10a4548052f6c',1,'PlotLimits']]],
  ['autoyrange_8',['autoYRange',['../struct_plot_limits.html#a5974109741f953cfc9e55f92208eb7c5',1,'PlotLimits']]]
];
