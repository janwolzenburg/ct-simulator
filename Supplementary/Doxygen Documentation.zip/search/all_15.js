var searchData=
[
  ['x_0',['X',['../class_vector3_d.html#a9dd2ad71f79259b438e22d633515a4ec',1,'Vector3D']]],
  ['x_1',['x',['../struct_index2_d.html#a9641b7f3b8dd51c3655cecb2ac5faf96',1,'Index2D::x'],['../struct_tuple2_d.html#a6508967e8a067f88551c297bf633d7cb',1,'Tuple2D::x'],['../class_index3_d.html#a7f5e51cad29bbde8d215d7ad2cfb2e01',1,'Index3D::x'],['../class_tuple3_d.html#ac0bb3faec2736d6ed7edd187b89a9cbf',1,'Tuple3D::x'],['../struct_pixel_coordinates.html#a58e924179ebcbf15179a36f531d1253c',1,'PixelCoordinates::x'],['../class_fl___grayscale_image_with_axis.html#a1b7eab1941bb91b8bfdb1d273680a28d',1,'Fl_GrayscaleImageWithAxis::x()']]],
  ['x_5fformat_5f_2',['x_format_',['../class_plot.html#abbc02d5759a4caf011b5fe384d1a437b',1,'Plot']]],
  ['x_5flabel_5f_3',['x_label_',['../class_plot.html#a3861be8262ec378daccabb8f4b0ef1d0',1,'Plot']]],
  ['x_5fvalues_4',['x_values',['../class_line_plot.html#a3e939238cea5bb0bec17847229549ffc',1,'LinePlot']]],
  ['xfactor_5',['xFactor',['../struct_plot_limits.html#aae3a3d257c0f72240e85817035c9f509',1,'PlotLimits']]],
  ['xrange_6',['xRange',['../struct_plot_limits.html#a26c85811b2eda83a9314bc3d3c6e48ba',1,'PlotLimits']]],
  ['xraydetector_7',['XRayDetector',['../class_x_ray_detector.html',1,'XRayDetector'],['../class_x_ray_detector.html#aa04cc9f87cff44ee5159804042b3b7c2',1,'XRayDetector::XRayDetector()']]],
  ['xraytube_8',['XRayTube',['../class_x_ray_tube.html',1,'XRayTube'],['../class_x_ray_tube.html#ab6ed90098ac6cb816ea79cf05d8dba20',1,'XRayTube::XRayTube()']]],
  ['xraytubeproperties_9',['XRayTubeProperties',['../class_x_ray_tube_properties.html',1,'XRayTubeProperties'],['../class_x_ray_tube_properties.html#a505cadd1a52d77162537f25f8a6e1e75',1,'XRayTubeProperties::XRayTubeProperties(const double anode_Voltage_V, const double anodeCurrent_A, const Material anode_material, const size_t number_of_rays_per_pixel, const bool has_filter, const double filter_cut_of_energy, const double filter_gradient)'],['../class_x_ray_tube_properties.html#a1541a6ed3eab87d1c2b31069ea8c8382',1,'XRayTubeProperties::XRayTubeProperties(void)'],['../class_x_ray_tube_properties.html#a5701b62cb97988db93ed024859c99941',1,'XRayTubeProperties::XRayTubeProperties(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)']]],
  ['xy_5fzm_10',['XY_Zm',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42afeb984c9ddc8843ff8b92d53ee7151e2',1,'Voxel']]],
  ['xy_5fzp_11',['XY_Zp',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a65d14909b6190f2d265f9080005abcf8',1,'Voxel']]],
  ['xz_5fym_12',['XZ_Ym',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a49fa90eaa3d4afb5233c05cf3d56287a',1,'Voxel']]],
  ['xz_5fyp_13',['XZ_Yp',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42aa442fba99489f461f28f459ed4054dcd',1,'Voxel']]]
];
