var searchData=
[
  ['xraydetector_0',['XRayDetector',['../class_x_ray_detector.html',1,'']]],
  ['xraytube_1',['XRayTube',['../class_x_ray_tube.html',1,'']]],
  ['xraytubeproperties_2',['XRayTubeProperties',['../class_x_ray_tube_properties.html',1,'']]]
];
