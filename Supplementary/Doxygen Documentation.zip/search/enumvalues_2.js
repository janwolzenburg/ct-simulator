var searchData=
[
  ['general_0',['General',['../class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858a0db377921f4ce762c62526131097968f',1,'MathematicalObject']]]
];
