var searchData=
[
  ['data_5f_0',['data_',['../class_matrix.html#aa9182feab706b8ad7893d2424c6161da',1,'Matrix']]],
  ['desired_5fenergy_5fresolution_5fev_1',['desired_energy_resolution_eV',['../class_scattering_cross_section.html#a3fa2803b9a9b091b98866f654d080fe0',1,'ScatteringCrossSection']]],
  ['detector_5ffocus_5fdistance_2',['detector_focus_distance',['../struct_physical_detector_properties.html#a97351d431be3f902ea4ab2fef30a1c2a',1,'PhysicalDetectorProperties::detector_focus_distance'],['../class_detector_properties.html#acfb03a89e9dfd4deaf39b0d275313c23',1,'DetectorProperties::detector_focus_distance']]],
  ['direction_5f_3',['direction_',['../class_line.html#ac47b55491b874aa8d75597fba30075cf',1,'Line']]],
  ['direction_5f1_5f_4',['direction_1_',['../class_surface.html#ae292c1ab1bae1d2804d33fea2a6cfabd',1,'Surface']]],
  ['direction_5f2_5f_5',['direction_2_',['../class_surface.html#a9f65f9a8a82dfe4be1b20b1e8b12ea5f',1,'Surface']]],
  ['distance_6',['distance',['../class_radon_coordinates.html#a8886f2fe676a19146ab173af9ede61a3',1,'RadonCoordinates']]]
];
