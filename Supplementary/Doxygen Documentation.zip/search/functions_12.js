var searchData=
[
  ['value_0',['value',['../class_fl___bound_input.html#a6d1a2214aa49189f4fa630ae0b2f48bb',1,'Fl_BoundInput::value(void) const'],['../class_fl___bound_input.html#a9081cad3847662560a35540b41a38dee',1,'Fl_BoundInput::value(const T new_value)']]],
  ['values_1',['values',['../class_backprojection_filter.html#a8d3d200d937a1c6e9ee331076ec36cb3',1,'BackprojectionFilter']]],
  ['vector3d_2',['Vector3D',['../class_vector3_d.html#ab33a038c9dc2c2029cfabe755b9cd45a',1,'Vector3D::Vector3D(const Coordinates coordinates)'],['../class_vector3_d.html#a2f4f35c04006ca8ab45448a09cdc6abf',1,'Vector3D::Vector3D(const Tuple3D components, const CoordinateSystem *const coordinate_system)'],['../class_vector3_d.html#a07e01a8e8a497cd93616a16b5b2774cd',1,'Vector3D::Vector3D(const class Unitvector3D &amp;unit_vector)'],['../class_vector3_d.html#a4c96ce0e3c660ca8615641c101f84f5b',1,'Vector3D::Vector3D(void)']]],
  ['voxel_3',['Voxel',['../class_voxel.html#a758cabd98005272767197e43fcdaf0e6',1,'Voxel::Voxel(const Point3D origin, const Tuple3D size, const VoxelData data)'],['../class_voxel.html#aab2cf291404c3a42b3841d287ad5788c',1,'Voxel::Voxel(void)']]],
  ['voxel_5fhits_4',['voxel_hits',['../class_ray.html#a194321f85a542002a8b0d911a114d21c',1,'Ray']]],
  ['voxel_5fsize_5',['voxel_size',['../class_model.html#a777f1be66b46bec1397a08ac08a951f7',1,'Model']]],
  ['voxeldata_6',['VoxelData',['../class_voxel_data.html#a81bc6a3736b6c7b8b081f995e6ab1732',1,'VoxelData::VoxelData(const double absorption_at_energy, const double energy_eV, const SpecialProperty special_properties=SpecialProperty::NoneP)'],['../class_voxel_data.html#ab3f5519f1ba27e1ca0cb64d4da953237',1,'VoxelData::VoxelData(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)'],['../class_voxel_data.html#a59d2ad18c1bf8babccc0b3177047d649',1,'VoxelData::VoxelData(void)']]]
];
