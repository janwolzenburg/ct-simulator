var searchData=
[
  ['z_0',['z',['../class_index3_d.html#a08580890c624c334ffce9afbf7cc2ddb',1,'Index3D::z'],['../class_tuple3_d.html#adc052b9005763da135bd78deed1e4f43',1,'Tuple3D::z']]]
];
