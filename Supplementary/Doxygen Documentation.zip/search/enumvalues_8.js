var searchData=
[
  ['yz_5fxm_0',['YZ_Xm',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a7bfc328b81b6446ced6d5596ad311790',1,'Voxel']]],
  ['yz_5fxp_1',['YZ_Xp',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42acca6220f2d2957db9002734d4eceb323',1,'Voxel']]]
];
