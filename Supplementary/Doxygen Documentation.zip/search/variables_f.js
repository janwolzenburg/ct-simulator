var searchData=
[
  ['r_0',['r',['../class_grid_index.html#a58d305fcd4cd92b6710714ac44f8ba7e',1,'GridIndex::r'],['../class_grid_coordinates.html#a081d4c1c489dd8f65ad159d967bb42f7',1,'GridCoordinates::r']]],
  ['ray_5fproperties_1',['ray_properties',['../class_ray_pixel_intersection.html#a4c043deee0ca1414ce82151416df935c',1,'RayPixelIntersection']]],
  ['ray_5fstep_5fsize_5fmm_2',['ray_step_size_mm',['../class_simulation_properties.html#afcbd070ec8af052b3f2520413509223d',1,'SimulationProperties']]],
  ['red_3',['red',['../struct_r_g_b.html#a27a7ad87f1e966cb05761741e57b06d2',1,'RGB']]],
  ['reset_5fprogram_5fstate_5fat_5fexit_5fbutton_5f_4',['reset_program_state_at_exit_button_',['../class_fl___main_window.html#a37a13abc164b0e3a79aaff9faf6ed13e',1,'Fl_MainWindow']]],
  ['reset_5fprogram_5fstate_5fcallback_5f_5',['reset_program_state_callback_',['../class_fl___main_window.html#aec0079707ea3cf21527ec511a1bd33fc',1,'Fl_MainWindow']]],
  ['rotation_5fangle_5fx_6',['rotation_angle_x',['../class_slice_plane.html#a473230b27a522b8085284c25031b3811',1,'SlicePlane']]],
  ['rotation_5fangle_5fy_7',['rotation_angle_y',['../class_slice_plane.html#a0e2f26fa49087413986f06625a339277',1,'SlicePlane']]],
  ['row_5fwidth_8',['row_width',['../struct_physical_detector_properties.html#af322f90c84eb10ced22fd58d4ee2f4f2',1,'PhysicalDetectorProperties::row_width'],['../class_detector_properties.html#a1b1fd3be809683365db35747fcadc451',1,'DetectorProperties::row_width']]]
];
