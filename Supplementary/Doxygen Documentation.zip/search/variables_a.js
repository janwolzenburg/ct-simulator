var searchData=
[
  ['materials_0',['materials',['../class_x_ray_tube_properties.html#a977650a4ff4231d11532294a5c550916',1,'XRayTubeProperties']]],
  ['max_5fangle_5fallowed_5fby_5fstructure_1',['max_angle_allowed_by_structure',['../struct_physical_detector_properties.html#a87d05e60620be1ced6d540b1315efa1d',1,'PhysicalDetectorProperties::max_angle_allowed_by_structure'],['../class_detector_properties.html#ac40f063b0e8b6de3d43715ee1d9b5f17',1,'DetectorProperties::max_angle_allowed_by_structure']]],
  ['max_5fscattering_5foccurrences_2',['max_scattering_occurrences',['../class_tomography_properties.html#a0884248b7293a5db0270899c15a3155b',1,'TomographyProperties']]],
  ['max_5fsystems_5fin_5ftree_3',['max_systems_in_tree',['../class_coordinate_system_tree.html#a27ccb80f58ca070848d7153a4a908cf5',1,'CoordinateSystemTree']]],
  ['mean_5fenergy_5fof_5ftube_4',['mean_energy_of_tube',['../class_tomography_properties.html#afad3ddd0a62efb2b4a3d35badc4a1286',1,'TomographyProperties']]],
  ['menu_5fgroup_5f_5',['menu_group_',['../class_fl___main_window.html#a55797e022e510b28526934625cb09d72',1,'Fl_MainWindow']]],
  ['metal_5fcolor_6',['metal_color',['../class_fl___grayscale_image.html#afb25952e8ee2efe4a0732d4c56ec81d0',1,'Fl_GrayscaleImage']]],
  ['model_5fcreator_5fbutton_5f_7',['model_creator_button_',['../class_fl___main_window.html#ad7b633df8e2ebe2d46799baf9394dd05',1,'Fl_MainWindow']]],
  ['model_5fview_5f_8',['model_view_',['../class_fl___main_window.html#a47b632114f4d5b021c773fea49157305',1,'Fl_MainWindow']]]
];
