var searchData=
[
  ['material_0',['Material',['../class_x_ray_tube_properties.html#a562173cce0c5c6afc18fbe755fbc0d71',1,'XRayTubeProperties']]],
  ['matherror_1',['MathError',['../class_mathematical_object.html#a62c5cfa8c12ad11a3657e6b822137858',1,'MathematicalObject']]]
];
