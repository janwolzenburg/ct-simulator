var searchData=
[
  ['shepplogan_0',['sheppLogan',['../class_backprojection_filter.html#ade6451f2da0153b5bdc9dc4ca8d3b302ac9e2fcba115c54b3659b1557efb55575',1,'BackprojectionFilter']]]
];
