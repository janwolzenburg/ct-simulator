var searchData=
[
  ['x_0',['X',['../class_vector3_d.html#a9dd2ad71f79259b438e22d633515a4ec',1,'Vector3D']]],
  ['x_1',['x',['../class_fl___grayscale_image_with_axis.html#a1b7eab1941bb91b8bfdb1d273680a28d',1,'Fl_GrayscaleImageWithAxis']]],
  ['xraydetector_2',['XRayDetector',['../class_x_ray_detector.html#aa04cc9f87cff44ee5159804042b3b7c2',1,'XRayDetector']]],
  ['xraytube_3',['XRayTube',['../class_x_ray_tube.html#ab6ed90098ac6cb816ea79cf05d8dba20',1,'XRayTube']]],
  ['xraytubeproperties_4',['XRayTubeProperties',['../class_x_ray_tube_properties.html#a505cadd1a52d77162537f25f8a6e1e75',1,'XRayTubeProperties::XRayTubeProperties(const double anode_Voltage_V, const double anodeCurrent_A, const Material anode_material, const size_t number_of_rays_per_pixel, const bool has_filter, const double filter_cut_of_energy, const double filter_gradient)'],['../class_x_ray_tube_properties.html#a1541a6ed3eab87d1c2b31069ea8c8382',1,'XRayTubeProperties::XRayTubeProperties(void)'],['../class_x_ray_tube_properties.html#a5701b62cb97988db93ed024859c99941',1,'XRayTubeProperties::XRayTubeProperties(const vector&lt; char &gt; &amp;binary_data, vector&lt; char &gt;::const_iterator &amp;current_byte)']]]
];
