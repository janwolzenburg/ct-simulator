var searchData=
[
  ['xy_5fzm_0',['XY_Zm',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42afeb984c9ddc8843ff8b92d53ee7151e2',1,'Voxel']]],
  ['xy_5fzp_1',['XY_Zp',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a65d14909b6190f2d265f9080005abcf8',1,'Voxel']]],
  ['xz_5fym_2',['XZ_Ym',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42a49fa90eaa3d4afb5233c05cf3d56287a',1,'Voxel']]],
  ['xz_5fyp_3',['XZ_Yp',['../class_voxel.html#a62451de909f32e9e4759ade00b9e0d42aa442fba99489f461f28f459ed4054dcd',1,'Voxel']]]
];
