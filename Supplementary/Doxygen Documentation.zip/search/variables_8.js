var searchData=
[
  ['image_5fpath_5f_0',['image_path_',['../class_plot.html#ae99dfeea2f5bbc0774911324a5e7c60d',1,'Plot']]],
  ['image_5fsize_5f_1',['image_size_',['../class_plot.html#a4c54493e1bb75a128af7ede3e964de9e',1,'Plot']]],
  ['import_5fprojections_5fbutton_5f_2',['import_projections_button_',['../class_fl___main_window.html#a18169a850fc3602efb8b5b779530508e',1,'Fl_MainWindow']]],
  ['import_5fprojections_5fcallback_5f_3',['import_projections_callback_',['../class_fl___main_window.html#aad78111319e1c982dd3015668b7f5d47',1,'Fl_MainWindow']]],
  ['import_5fprojections_5ffile_5fchooser_5f_4',['import_projections_file_chooser_',['../class_fl___main_window.html#a655317f7601f0bcbf04e4ddc180788e4',1,'Fl_MainWindow']]],
  ['intersection_5fexists_5f_5',['intersection_exists_',['../class_line_surface_intersection.html#a04485422288d02b7c0aa5b7a13373752',1,'LineSurfaceIntersection']]],
  ['intersection_5fpoint_5f_6',['intersection_point_',['../class_line_surface_intersection.html#a962fbd622136c5060dd45a00a68ae194',1,'LineSurfaceIntersection']]]
];
