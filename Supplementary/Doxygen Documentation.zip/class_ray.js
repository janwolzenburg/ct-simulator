var class_ray =
[
    [ "Ray", "class_ray.html#a2da377b0937aa6bb7594c4669804be8e", null ],
    [ "Ray", "class_ray.html#a98e70d9d0cf1680472d63bdc660d55a6", null ],
    [ "Ray", "class_ray.html#aadfb3e322ac986cf92d4844b208585ce", null ],
    [ "ConvertTo", "class_ray.html#aa0259875b15c0fdfffcab8ab16e75b79", null ],
    [ "GetLineParameter", "class_ray.html#a3bd02ce676ebc30570c555dcfeda67b4", null ],
    [ "GetPossibleVoxelExits", "class_ray.html#a13b05a4245b86cafc23a519a2567f984", null ],
    [ "IncrementHitCounter", "class_ray.html#ab1f5c8b7baa670eb2d5e6b8d4b93d73a", null ],
    [ "IsParameterInBounds", "class_ray.html#ad8cdf8f3845c528e37532e3bb00100b8", null ],
    [ "ProjectOnXYPlane", "class_ray.html#a9ad15f477dea3b693d11dd4938eedb98", null ],
    [ "properties", "class_ray.html#a7174422b5bd7857abf26d3460626b6f5", null ],
    [ "ResetHitCounter", "class_ray.html#a93b3d4582b6f948c63faf11329c537f0", null ],
    [ "ScaleSpectrumEvenly", "class_ray.html#accab3de63ac615f6f7989690d28dd2ab", null ],
    [ "Scatter", "class_ray.html#a06bda75d3c3b4da07cb7ccce12841371", null ],
    [ "SetDirection", "class_ray.html#a133137ee3c6d6460d56b77000d9e2c4f", null ],
    [ "SetExpectedPixelIndex", "class_ray.html#ab4050469c6a98405377ecbb081922cdd", null ],
    [ "SetOrigin", "class_ray.html#a987140fc50112664943906666294792a", null ],
    [ "UpdateProperties", "class_ray.html#ac61d162cb7e2eb9e402beb9ddac9451d", null ],
    [ "voxel_hits", "class_ray.html#a194321f85a542002a8b0d911a114d21c", null ]
];