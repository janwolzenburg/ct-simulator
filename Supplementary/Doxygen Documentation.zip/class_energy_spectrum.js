var class_energy_spectrum =
[
    [ "EnergySpectrum", "class_energy_spectrum.html#aca1390846932756fd995dfa55e53d668", null ],
    [ "EnergySpectrum", "class_energy_spectrum.html#a212b924ec1fbea74ba0cfd1b3438b052", null ],
    [ "EnergySpectrum", "class_energy_spectrum.html#aba195ebe6959a604cc43626098f25085", null ],
    [ "data", "class_energy_spectrum.html#a1bf065f25b0277bfd2e865bc46db4e8b", null ],
    [ "GetAbsorped", "class_energy_spectrum.html#aafd08bdf532ac280c8bc286ced9820f6", null ],
    [ "GetEnergy", "class_energy_spectrum.html#a31b80b48650fbbc502a9f47c19704fb4", null ],
    [ "GetEnergyIndex", "class_energy_spectrum.html#a78b38ba41d055358e67cedf11e7622c6", null ],
    [ "GetEvenlyScaled", "class_energy_spectrum.html#a3d1e4e0df448953cf7059175576a49f6", null ],
    [ "GetMaxEnergy", "class_energy_spectrum.html#a92ae03f4a4731ca8f14cabc1e57bbc9e", null ],
    [ "GetMinEnergy", "class_energy_spectrum.html#aa98c7eab8aaeaaa6e7d397bae7e87529", null ],
    [ "GetNumberOfEnergies", "class_energy_spectrum.html#ad2f388000b448baf728c1068ad7ef264", null ],
    [ "GetPhotonflow", "class_energy_spectrum.html#a3107dafc803431733cdb67c448a0173a", null ],
    [ "GetSum", "class_energy_spectrum.html#a71bf576829a8922e148a7edf4f4a91ef", null ],
    [ "GetTotalPower", "class_energy_spectrum.html#acb749bc0b579a0126eddfb2b0ab8a77b", null ],
    [ "GetTotalPowerIn_eVPerSecond", "class_energy_spectrum.html#acd3f4cc15b090c595a37456bf2db4680", null ],
    [ "mean_energy", "class_energy_spectrum.html#ab20e1b134c165e90a8ab998dcc771419", null ],
    [ "Modify", "class_energy_spectrum.html#a10d9b312aecc6c816667e93fb1a8b656", null ],
    [ "ScaleEnergy", "class_energy_spectrum.html#af9eb4ef18d911b48755f20b648a00c25", null ],
    [ "ScaleEnergy", "class_energy_spectrum.html#a82f3b91c10507ba3d8431d37e6ea1a8e", null ],
    [ "ScaleEvenly", "class_energy_spectrum.html#a8db234a608389683380c46a37d778f8b", null ]
];