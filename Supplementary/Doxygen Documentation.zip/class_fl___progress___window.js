var class_fl___progress___window =
[
    [ "Fl_Progress_Window", "class_fl___progress___window.html#aca2932c14ef148cd1aece4a8d106fd5e", null ],
    [ "ChangeLineText", "class_fl___progress___window.html#acb0bf62e24acb8fadd64c6226c49051f", null ],
    [ "number_of_lines", "class_fl___progress___window.html#a4a17f467e9816a2cd58b9b23887448a5", null ]
];