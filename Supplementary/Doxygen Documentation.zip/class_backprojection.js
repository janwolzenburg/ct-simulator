var class_backprojection =
[
    [ "Backprojection", "class_backprojection.html#a1d7605de2f44e39c7950440b6eeeb0dd", null ],
    [ "Backprojection", "class_backprojection.html#a23214fc19806a32e37dae76e3a9c6da5", null ],
    [ "Backprojection", "class_backprojection.html#a0653e50100ecea8758636c9f0651000f", null ],
    [ "getGrid", "class_backprojection.html#ac95c6ba5059457287227e52d337bf4ad", null ],
    [ "Serialize", "class_backprojection.html#acca09168ad4ffe3c1956f0f09404427a", null ]
];