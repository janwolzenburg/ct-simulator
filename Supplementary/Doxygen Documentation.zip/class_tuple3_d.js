var class_tuple3_d =
[
    [ "Tuple3D", "class_tuple3_d.html#aef557b05a24f6534170a68abe7fdcc88", null ],
    [ "Tuple3D", "class_tuple3_d.html#a2624ba2f42f12034451a6e25cf956b32", null ],
    [ "Tuple3D", "class_tuple3_d.html#a48e9fc1b89317138f48a2b05e0846604", null ],
    [ "Serialize", "class_tuple3_d.html#abcca27ee1a761765822e17f73a98038a", null ],
    [ "x", "class_tuple3_d.html#ac0bb3faec2736d6ed7edd187b89a9cbf", null ],
    [ "y", "class_tuple3_d.html#a047c6f4531a13a3da96a446869e8b434", null ],
    [ "z", "class_tuple3_d.html#adc052b9005763da135bd78deed1e4f43", null ]
];