var class_voxel_data =
[
    [ "VoxelData", "class_voxel_data.html#a81bc6a3736b6c7b8b081f995e6ab1732", null ],
    [ "VoxelData", "class_voxel_data.html#ab3f5519f1ba27e1ca0cb64d4da953237", null ],
    [ "VoxelData", "class_voxel_data.html#a59d2ad18c1bf8babccc0b3177047d649", null ],
    [ "AddSpecialProperty", "class_voxel_data.html#a8e8155705c787e5472ba8026662671e7", null ],
    [ "GetAbsorptionAtEnergy", "class_voxel_data.html#ac15315022d94768e0bcbb65ac2501d30", null ],
    [ "GetAbsorptionAtReferenceEnergy", "class_voxel_data.html#a7ffcfd8a5c5814b9cdf3e9fa0378453e", null ],
    [ "HasSpecialProperty", "class_voxel_data.html#a8b1653b546fda5c3f2b5728a02958e37", null ],
    [ "HasSpecificProperty", "class_voxel_data.html#ac065673920321f025880832a3586e553", null ],
    [ "operator<", "class_voxel_data.html#aaed318f6c731de180a568e0d3e7224bc", null ],
    [ "operator>", "class_voxel_data.html#a54c7844561948c35e52c3e93260d14c8", null ],
    [ "RemoveSpecialProperty", "class_voxel_data.html#a0f03c1664ab4d376617fc494d5b1df32", null ],
    [ "Serialize", "class_voxel_data.html#aa21f5bff1388b324bc1136da7b55ce52", null ]
];