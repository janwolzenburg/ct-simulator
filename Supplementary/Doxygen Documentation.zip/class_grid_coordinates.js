var class_grid_coordinates =
[
    [ "GridCoordinates", "class_grid_coordinates.html#ac4a0d7117d1839767c1fc75c4bae68a4", null ],
    [ "GridCoordinates", "class_grid_coordinates.html#afc552a3ebf4112afb2dfbdb28fbc976f", null ],
    [ "GridCoordinates", "class_grid_coordinates.html#a6985fe50de0afbf7cd9f9d15a8f4ef14", null ],
    [ "Serialize", "class_grid_coordinates.html#a8cdd380d1d59af6990a41cd71c133b98", null ],
    [ "c", "class_grid_coordinates.html#ac25bf1d7ac181969b4bce0dd5bc6c963", null ],
    [ "r", "class_grid_coordinates.html#a081d4c1c489dd8f65ad159d967bb42f7", null ]
];