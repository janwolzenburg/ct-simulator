var class_grayscale_image =
[
    [ "GrayscaleImage", "class_grayscale_image.html#a690a97f88056951cb7633ee9b433c3e4", null ],
    [ "GrayscaleImage", "class_grayscale_image.html#a3623c89cd12eb4ad4e92f028e256f5f5", null ],
    [ "GrayscaleImage", "class_grayscale_image.html#a2eadd94d24496aac3a5009725422cfda", null ],
    [ "GrayscaleImage", "class_grayscale_image.html#a0f432b4e2b9115f7ea1164c61974fc69", null ],
    [ "GrayscaleImage", "class_grayscale_image.html#a9d7afa366988cd927209f6cc063e9f94", null ],
    [ "GrayscaleImage", "class_grayscale_image.html#a043f583310bcea4045891bf3efeba600", null ],
    [ "AdjustContrast", "class_grayscale_image.html#ad7d6cc7be7d117ebbee32d25b526ed9b", null ],
    [ "AdjustContrast", "class_grayscale_image.html#aa038622328dcebab23e387180ba83745", null ],
    [ "GetData", "class_grayscale_image.html#ad043977e531f044bc2c6357ad4bb3c27", null ],
    [ "GetImageData", "class_grayscale_image.html#a611dbea5ac201a649255d5c15ad3f458", null ],
    [ "GetIndex", "class_grayscale_image.html#a45ce8c59e2d522a429ef104749dab39f", null ],
    [ "GetMaximum", "class_grayscale_image.html#a37d8891e3cb4365f92af283a30638334", null ],
    [ "GetMinimum", "class_grayscale_image.html#a5a19ce035e46f7b8a1fb773b5a6040d2", null ],
    [ "GetPixelData", "class_grayscale_image.html#ae54ce59a6b4eac9d51b4027e464b8046", null ],
    [ "height", "class_grayscale_image.html#aa15b8138fd5a1caa70586790b293963d", null ],
    [ "number_of_pixel", "class_grayscale_image.html#a56301d65055b69bd75ead1ce4864c4d1", null ],
    [ "Serialize", "class_grayscale_image.html#ae157e5cf310e74605ef94f4722e7a582", null ],
    [ "SetData", "class_grayscale_image.html#a4ed2d89aadbda32fdd0575521a85f47c", null ],
    [ "width", "class_grayscale_image.html#a380d029a0215a8bf256921a659c5e683", null ]
];