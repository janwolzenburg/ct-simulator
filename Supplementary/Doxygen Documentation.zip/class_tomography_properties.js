var class_tomography_properties =
[
    [ "TomographyProperties", "class_tomography_properties.html#a59f88fe307b4b1b9ddc16f7ecf4c1ba5", null ],
    [ "TomographyProperties", "class_tomography_properties.html#a1d7c8e9300b54eb3ad0da45d3f1a4dc5", null ],
    [ "TomographyProperties", "class_tomography_properties.html#a7efd9a84558ef4535c215c0a9fa52ef6", null ],
    [ "Serialize", "class_tomography_properties.html#a3fc084db8202a51bbc24094b8bdfaa77", null ],
    [ "filter_active", "class_tomography_properties.html#a98818dfc97607b8377537107d6d59fc2", null ],
    [ "max_scattering_occurrences", "class_tomography_properties.html#a0884248b7293a5db0270899c15a3155b", null ],
    [ "mean_energy_of_tube", "class_tomography_properties.html#afad3ddd0a62efb2b4a3d35badc4a1286", null ],
    [ "name", "class_tomography_properties.html#a2cd272b6a28e6c825ce4a74204ece48e", null ],
    [ "scatter_propability_correction", "class_tomography_properties.html#aea1e604807b1ea7902173636ab8bc9e6", null ],
    [ "scattered_ray_absorption_factor", "class_tomography_properties.html#aa5cd18ac5aa71818db5e07d3d96b0c47", null ],
    [ "scattering_enabled", "class_tomography_properties.html#abef24d37822b08151eb157657df13020", null ],
    [ "simulation_quality", "class_tomography_properties.html#aaafdbff9d7eaa99c2c664223e39732da", null ],
    [ "use_simple_absorption", "class_tomography_properties.html#ab73de1c55a2aa2af9da5cbe970d555cc", null ]
];