var class_radon_point =
[
    [ "RadonPoint", "class_radon_point.html#a4f9599b276f2bc490235beaa19ab6427", null ],
    [ "value", "class_radon_point.html#a7707eafadda407d1e1aa247cbb9a5960", null ]
];